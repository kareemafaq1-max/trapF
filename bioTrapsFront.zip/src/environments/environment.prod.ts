const domainUrl = 'https://TrapsysAPI.epcmms.com/';
export const environment = {
  production: true,
  domainUrl,
  apiPath: `${domainUrl}api/`,
};
