import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'serial',
})
export class SerialPipe implements PipeTransform {
  transform(value: string): any {
    let x;
    if (value.slice(0, 12) == 'EG-123-2020-') {
      x = value.slice(12);
    } else {
      x = value;
    }
    return x;
  }
}
