import { Pipe, PipeTransform } from '@angular/core';
import { TrapService } from '@modules/services/trap.service';

@Pipe({
  name: 'fakeLat'
})
export class FakeLatPipe implements PipeTransform {
constructor(private trapService:TrapService){}
  transform(lat: any): any {
    if (lat == 0) {
      let rNum= Math.floor(Math.random() * 9999)
      lat = Number(
        this.trapService.fakeLat.toString().substring(this.trapService.fakeLat.toString().length - 3, 0) + rNum
      )
    }
    return lat;
  }

}
