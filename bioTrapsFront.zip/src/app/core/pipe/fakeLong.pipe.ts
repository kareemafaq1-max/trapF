import { Pipe, PipeTransform } from '@angular/core';
import { TrapService } from '@modules/services/trap.service';

@Pipe({
  name: 'fakeLong',
})
export class FakeLongPipe implements PipeTransform {
  constructor(private trapService: TrapService) {}
  transform(long: any): any {
    if (long == 0) {
      let rNum = Math.floor(Math.random() * 9999).toString();

      long = Number(
        this.trapService.fakeLong
          .toString()
          .substring(this.trapService.fakeLong.toString().length - 3, 0) + rNum
      );
    }
    return long;
  }
}
