import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(arr: any[], name: string,id:string): any {
    const set = new Set()
    if (Array.isArray(arr)) {
      arr.forEach(ele => {
        set.add({name:ele[name],id:ele[id] ?? ele[name] })
      });
    }
    return Array.from(set);
  }

}
