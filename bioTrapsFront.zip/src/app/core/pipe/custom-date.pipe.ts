import { Pipe, PipeTransform } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import * as moment from 'moment';

@Pipe({
  name: 'customDate'
})

export class CustomDatePipe implements PipeTransform {

  constructor(private tranlate: TranslateService) { }

  transform(value: Date): any {
    if (!value) return null;
    moment.locale(this.tranlate.currentLang);
    return moment(value).format('L');
  }

}
