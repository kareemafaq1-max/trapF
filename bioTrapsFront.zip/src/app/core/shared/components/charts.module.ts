import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ColumnChartsComponent } from './apexcharts/column-charts/column-charts.component';
import { GradientDonutComponent } from './apexcharts/gradient-donut/gradient-donut.component';
import { NgApexchartsModule } from 'ng-apexcharts';
import { ColumnChartsBasicComponent } from './apexcharts/column-charts-basic/column-charts-basic.component';
import { LineChartsZoomableComponent } from './apexcharts/line-charts-zoomable/line-charts-zoomable.component';
import { PieChartsComponent } from './apexcharts/pie-charts/pie-charts.component';
import { ChartModule } from 'primeng/chart';
import { RadialBarChartsComponent } from './apexcharts/radial-bar-charts/radial-bar-charts.component';


@NgModule({
  declarations: [
    ColumnChartsComponent,
    GradientDonutComponent,
    ColumnChartsBasicComponent,
    LineChartsZoomableComponent,
    PieChartsComponent,
    RadialBarChartsComponent
  ],
  imports: [
    CommonModule,
    NgApexchartsModule,
    ChartModule
  ],
  exports:[
    ColumnChartsComponent,
    GradientDonutComponent,
    ColumnChartsBasicComponent,
    LineChartsZoomableComponent,
    PieChartsComponent,
    RadialBarChartsComponent,
    NgApexchartsModule
  ]
})
export class ChartsModule { }
