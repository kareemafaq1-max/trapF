import { Component, Input, OnChanges, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import {
  ApexAxisChartSeries,
  ApexChart,
  ChartComponent,
  ApexDataLabels,
  ApexPlotOptions,
  ApexYAxis,
  ApexLegend,
  ApexStroke,
  ApexXAxis,
  ApexFill,
  ApexTooltip
} from "ng-apexcharts";

export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  dataLabels: ApexDataLabels;
  plotOptions: ApexPlotOptions;
  yaxis: ApexYAxis;
  xaxis: ApexXAxis;
  fill: ApexFill;
  tooltip: ApexTooltip;
  stroke: ApexStroke;
  legend: ApexLegend;
};

@Component({
  selector: 'app-column-charts-basic',
  templateUrl: './column-charts-basic.component.html',
  styleUrls: ['./column-charts-basic.component.css']
})
export class ColumnChartsBasicComponent implements OnChanges {
  @ViewChild("chart") chart!: ChartComponent;
  @Input() data:any[]=[];
  @Input() chartOptions: Partial<ChartOptions> | any;
  constructor() {
    this.chartOptions = {
      series: [
        {
          name: "Net Profit",
          data: [1, 1, 1, 1, 1, 1 ,1, 1, 1, 1, 1, 1]
        },
        {
          name: "Revenue",
          data: [1, 1, 1, 1, 1, 1 ,1, 1, 1, 1, 1, 1]
        },
        {
          name: "Free Cash Flow",
          data: [1, 1, 1, 1, 1, 1 ,1, 1, 1, 1, 1, 1]
        },
        {
          name: "Free Cash Flow",
          data: [1, 1, 1, 1, 1, 1 ,1, 1, 1, 1, 1, 1]
        },
      ],
      chart: {
        type: "bar",
        height: 350
      },
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: "55%",
          endingShape: "rounded"
        }
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        show: true,
        width: 6,
        colors: ["transparent"]
      },
      xaxis: {
        categories: [
          "Jan",
          "Feb",
          "Mar",
          "Apr",
          "May",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Oct",
          "Nov",
          "Des"
        ]
      },
      yaxis: {
        title: {
          text: ""
        }
      },
      fill: {
        opacity: 1
      },
      tooltip: {
        y: {
          formatter: function(val:any) {
            return "$ " + val + " thousands";
          }
        }
      }
    };
   }

  ngOnChanges(change:SimpleChanges): void {
    if (change['data'].currentValue) {
      this.chartOptions = {
        series: [
          {
            name: "Mosuquitoes",
            data: this.data.map(x=>x.mosuqitoesCount)
          },
          {
            name: "Small",
            data: this.data.map(x=>x.smallCount)
          },
          {
            name: "Other",
            data: this.data.map(x=>x.flyesCount)
          },
          {
            name: "Large Mosuqitoes",
            data: this.data.map(x=>x.largeCount)
          },
        ],
        chart: {
          type: "bar",
          height: 350
        },
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: "55%",
            endingShape: "rounded"
          }
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          show: true,
          width: 6,
          colors: ["transparent"]
        },
        xaxis: {
          categories: this.data.map(x => x.date)
        },
        yaxis: {
          title: {
            text: ""
          }
        },
        fill: {
          opacity: 1
        },
        tooltip: {
          y: {
            formatter: function(val:any) {
              return "" + val + " thousands";
            }
          }
        }
      };
    }
  }

}
