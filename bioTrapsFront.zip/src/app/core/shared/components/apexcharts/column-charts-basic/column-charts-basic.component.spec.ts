import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ColumnChartsBasicComponent } from './column-charts-basic.component';

describe('ColumnChartsBasicComponent', () => {
  let component: ColumnChartsBasicComponent;
  let fixture: ComponentFixture<ColumnChartsBasicComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ColumnChartsBasicComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ColumnChartsBasicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
