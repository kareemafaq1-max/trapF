import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LineChartsZoomableComponent } from './line-charts-zoomable.component';

describe('LineChartsZoomableComponent', () => {
  let component: LineChartsZoomableComponent;
  let fixture: ComponentFixture<LineChartsZoomableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LineChartsZoomableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LineChartsZoomableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
