import { Component, Input, OnChanges, OnInit, SimpleChange, SimpleChanges, ViewChild } from '@angular/core';
import {
  ChartComponent,
  ApexAxisChartSeries,
  ApexChart,
  ApexXAxis,
  ApexDataLabels,
  ApexTooltip,
  ApexStroke
} from "ng-apexcharts";

export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  xaxis: ApexXAxis;
  stroke: ApexStroke;
  tooltip: ApexTooltip;
  dataLabels: ApexDataLabels;
};


@Component({
  selector: 'app-line-charts-zoomable',
  templateUrl: './line-charts-zoomable.component.html',
  styleUrls: ['./line-charts-zoomable.component.css']
})
export class LineChartsZoomableComponent implements OnChanges {
  // @ViewChild("chart") chart!: ChartComponent;
  // public chartOptions: Partial<ChartOptions> | any;
  @Input() colors: string = '#000';
  @Input() bg_color: string = '#fff';
  @Input() text: string = '';
  @Input() data: any[] = [];
  options: any = {
    maintainAspectRatio: false,
    responsive: false,
    aspectRatio: 0.6,
    plugins: {
      legend: {
        labels: {
          color: this.colors
        }
      }
    },
    scales: {
      x: {
        ticks: {
          color: this.colors
        },
        grid: {
          color: this.colors
        }
      },
      y: {
        ticks: {
          color: this.colors
        },
        grid: {
          color: this.colors
        }
      }
    }
  }
  dataChart: any = {
    labels: ['January', 'February', 'March', 'April', 'May', 'June'],
    datasets: [
      {
        label: 'Third Dataset',
        data: [12, 51, 62, 33, 21, 62],
        fill: true,
        borderColor: 'transparent',
        tension: 0.4,
        backgroundColor: 'transparent'
      }
    ]
  };

  constructor() {
    this.options = {
      maintainAspectRatio: false,
      aspectRatio: 0.6,
      plugins: {
        legend: {
          labels: {
            color: 'transparent'
          }
        }
      },
      scales: {
        x: {
          ticks: {
            color: '#000'
          },
          grid: {
            color: '#eeee'
          }
        },
        y: {
          ticks: {
            color: '#000'
          },
          grid: {
            color: '#eeee'
          }
        }
      }
    };

  }

  ngOnChanges(change: SimpleChanges): void {
    if (change['data']?.currentValue?.length > 0) {
      this.dataChart = {
        labels: this.data.map(x => x.date),
        datasets: [
          {
            label: `${this.text} Count`,
            data: this.data.map(x => x.insectsCount),
            fill: true,
            borderColor: this.colors,
            tension: 0.4,
            backgroundColor: 'transparent'
          }
        ]
      };
    }

  }


}
