import { Component, Input, OnChanges, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { ApexPlotOptions, ApexStroke, ChartComponent } from "ng-apexcharts";

import {
  ApexNonAxisChartSeries,
  ApexResponsive,
  ApexChart,
  ApexFill,
  ApexDataLabels,
  ApexLegend
} from "ng-apexcharts";

export type ChartOptions = {
  series: ApexNonAxisChartSeries;
  chart: ApexChart;
  responsive: ApexResponsive[];
  labels: any;
  fill: ApexFill;
  legend: ApexLegend;
  dataLabels: ApexDataLabels;
  plotOptions: ApexPlotOptions;
  stroke: ApexStroke
  colors: any;
};

@Component({
  selector: 'app-gradient-donut',
  templateUrl: './gradient-donut.component.html',
  styleUrls: ['./gradient-donut.component.css']
})
export class GradientDonutComponent implements OnChanges {
  @Input() text: string = '';
  @Input() data: any;

  options = {
    cutout: '60%',
    plugins: {
      legend: {
        labels: {
          color: '#000'
        }
      }
    }
  };

  dataChart: any = {
    labels: [
      "Mosuquitoes",
      "Small Mosuqitoes",
      "Other",
      "Large Mosuqitoes"],
    datasets: [
      {
        data: [1, 1, 1, 1],
        backgroundColor: ["#ccc", "#ccc", "#ccc", "#ccc"],
        hoverBackgroundColor: ["#0CE870", "#2190ff", "#EAA100", "#FF4E00"]
      }
    ]
  };

  constructor() {
  }

  ngOnChanges(change: SimpleChanges): void {
    if (change['data']?.currentValue) {
      // if(
      //   this.data.mosuqitoesCount && 
      //   this.data.smallCount && 
      //   this.data.flyesCount &&
      //   this.data.largeCount 
      // ){
        
        this.dataChart = {
          labels: [
            `Mosuquitoes - (${this.data.mosuqitoesCount})`,
            `Small Mosuqitoes - (${this.data.smallCount})`,
            `Other - (${this.data.flyesCount})`,
            `Large Mosuqitoes - (${this.data.largeCount})`],
          datasets: [
            {
              data: [this.data.mosuqitoesCount ,
                this.data.smallCount ,
                this.data.flyesCount,
                this.data.largeCount] ,
              backgroundColor: ["#0CE89D", "#2E85FF", "#EAA113", "#FF4E42"],
              hoverBackgroundColor: ["#0CE870", "#2190ff", "#EAA100", "#FF4E00"]
            }
          ]
        }
      // }else{
      //   this.dataChart = {
      //     labels: [
      //       "Mosuquitoes - (0)",
      //       "Small Mosuqitoes - (0)",
      //       "Fly - (0)",
      //       "Large Mosuqitoes - (0)"],
      //     datasets: [
      //       {
      //         data: [1, 1, 1, 1],
      //         backgroundColor: ["#ccc", "#ccc", "#ccc", "#ccc"],
      //         hoverBackgroundColor: ["#0CE870", "#2190ff", "#EAA100", "#FF4E00"]
      //       }
      //     ]
      //   }
      // }

    }
  }
}
