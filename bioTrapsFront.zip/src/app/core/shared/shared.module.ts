import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GoogleMapsModule } from '@angular/google-maps';
import {
  FaIconLibrary,
  FontAwesomeModule,
} from '@fortawesome/angular-fontawesome';
import {
  faAngleRight,
  faAnglesLeft,
  faAnglesRight,
  faArrowsUpDownLeftRight,
  faBars,
  faBarsProgress,
  faBugs,
  faChartColumn,
  faCircleCheck,
  faCircleMinus,
  faCirclePlus,
  faCircleXmark,
  faCow,
  faCreditCard,
  faEarthAsia,
  faEye,
  faFileExcel,
  faFilePdf,
  faFileWord,
  faHouse,
  faLungsVirus,
  faMap,
  faMortarPestle,
  faPencil,
  faPenToSquare,
  faPeopleRoof,
  faPlus,
  faScrewdriverWrench,
  faSyringe,
  faTableList,
  faTrash,
  faUserGroup,
  faViruses,
  faWrench,
  faXmark,
} from '@fortawesome/free-solid-svg-icons';
import { ChartlineComponent } from '@modules/chartline/chartline.component';
import { CustomDatePipe } from '@modules/custom-date.pipe';
import { FakeLatPipe } from '@modules/fakeLat.pipe';
import { FakeLongPipe } from '@modules/fakeLong.pipe';
import { FilterPipe } from '@modules/filter.pipe';
import { MarkerMapComponent, iconMapPipe } from '@modules/marker-map/marker-map.component';
import { PrimeNGModule } from '@modules/primeng.module';
// import { NgApexchartsModule } from 'ng-apexcharts';
import { NgxUiLoaderModule } from 'ngx-ui-loader';
import { SerialPipe } from '../pipe/serial.pipe';
import { ChartsModule } from './components/charts.module';
import { KnobModule } from 'primeng/knob';
import { LoadingModule } from '@modules/loading/loading.module';
@NgModule({
  declarations: [
    CustomDatePipe,
    FilterPipe,
    SerialPipe,
    MarkerMapComponent,
    ChartlineComponent,
    FakeLongPipe,
    FakeLatPipe,
    iconMapPipe
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    GoogleMapsModule,
    // NgApexchartsModule,
    PrimeNGModule,
    // NgxUiLoaderModule,
    ChartsModule,
    KnobModule,
    LoadingModule
  ],
  exports: [
    PrimeNGModule,
    FormsModule,
    ReactiveFormsModule,
    CustomDatePipe,
    FakeLongPipe,
    FakeLatPipe,
    FilterPipe,
    SerialPipe,
    FontAwesomeModule,
    // NgxUiLoaderModule,
    MarkerMapComponent,
    ChartlineComponent,
    // NgApexchartsModule,
  ],
})
export class SharedModule {
  constructor(library: FaIconLibrary) {
    library.addIcons(
      faPlus,
      faEye,
      faPencil,
      faTrash,
      faScrewdriverWrench,
      faWrench,
      faCow,
      faMortarPestle,
      faBugs,
      faEarthAsia,
      faViruses,
      faLungsVirus,
      faSyringe,
      faHouse,
      faChartColumn,
      faMap,
      faCircleMinus,
      faCircleXmark,
      faCircleCheck,
      faCirclePlus,
      faFileWord,
      faFilePdf,
      faArrowsUpDownLeftRight,
      faUserGroup,
      faAngleRight,
      faAnglesRight,
      faAnglesLeft,
      faBars,
      faXmark,
      faPeopleRoof,
      faBarsProgress,
      faFileExcel,
      faCreditCard,
      faTableList,
      faPenToSquare
    );
  }
}
