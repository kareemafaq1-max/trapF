import { Row, Workbook, Worksheet } from 'exceljs';
import * as fs from 'file-saver';
import * as htmlToImage from 'html-to-image';


export class GenerateExcel {

    constructor() { }

    async generateExcel(reportTitle: string, header: string[], data: any[]) {

        // data = [
        //     [2007, 1, "Volkswagen ", "Volkswagen Passat", 1267, 10],
        //     [2007, 1, "Toyota ", "Toyota Rav4", 819, 6.5],
        //     [2007, 1, "Toyota ", "Toyota Avensis", 787, 6.2],
        //     [2007, 1, "Volkswagen ", "Volkswagen Golf", 720, 5.7],
        //     [2007, 1, "Toyota ", "Toyota Corolla", 691, 5.4],
        //   ];
        // Create workbook and worksheet
        const workbook = new Workbook();
        const worksheet = workbook.addWorksheet('Sharing Data');

        // Add Row and formatting
        const titleRow1 = worksheet.addRow(['وزارة البيئة والمياه والزراعة']);
        titleRow1.font = { name: 'Corbel', family: 4, size: 16, bold: true };
        titleRow1.alignment = { horizontal: 'center', vertical: 'middle' };
        worksheet.mergeCells('A1:D3');

        //Add Image
        await this.getBase64ImageFromUrl('assets/img/logo.png').then((dataUrl: any) => {
            let logo = workbook.addImage({ base64: dataUrl, extension: 'png' });
            worksheet.addImage(logo, 'O1:P5');
        })
        worksheet.addRow([]);
        // Add Row and formatting
        const titleRow = worksheet.addRow([reportTitle ?? 'تقرير 1']);
        titleRow.font = { name: 'Corbel', family: 4, size: 16, bold: true };
        titleRow.alignment = { horizontal: 'left', vertical: 'middle' };
        worksheet.mergeCells('A5:J6',);

        worksheet.addRow([]);
        worksheet.addRow([]);

        // Add Header Row
        const headerRow = worksheet.addRow(header);

        // Cell Style : Fill and Border
        headerRow.eachCell((cell, number) => {
            cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFF6500' }, bgColor: { argb: 'FF0000FF' } };
            cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
        });

        // Add Data and Conditional Formatting
        data.forEach((d: any) => { worksheet.addRow(d); });

        // Generate Excel File with given name
        workbook.xlsx.writeBuffer().then((data: any) => {
            const blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
            fs.saveAs(blob, 'تقرير.xlsx');
        });

    }

    /**
     * This Function To Merge Cells
     * @param Input Column Name like 'A1:A10'
     */
    mergeCell(columnName: string, worksheet: Worksheet): void {
        worksheet.mergeCells(columnName);
    }

    headStyle1(row: Row): Row {
        row.font = { name: 'Century Gothic', family: 4, size: 16, bold: true };
        row.alignment = { horizontal: 'center', vertical: 'middle' };
        return row;
    }

    headStyle2(row: Row): Row {
        row.font = { name: 'Century Gothic', family: 4, size: 16, bold: true };
        row.alignment = { horizontal: 'center', vertical: 'middle' };
        return row;
    }

    headStyle3(row: Row): Row {
        row.font = {name: 'Century Gothic',  bold: true, size: 16, family: 4 };
        row.alignment = { horizontal: 'right', vertical: 'middle' };
        return row;
    }

    headStyle4(row: Row): Row {
        row.font = {name: 'Century Gothic',  bold: true, size: 12, family: 4 };
        row.alignment = { horizontal: 'right', vertical: 'middle' };
        return row;
    }

    tableHeadStyle1(row: Row, skipRow: number=0): Row {
        row.eachCell((cell, number) => {
            if (number>skipRow) {
                cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '4baf50' }, bgColor: { argb: '4baf50' } };
                cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
                cell.font={name: 'Century Gothic', size: 12, bold: true};
                cell.alignment={vertical:'middle',horizontal:'center'}
            }
        });
        return row;
    }

    async getBase64ImageFromUrl(imageUrl: string) {
        var res = await fetch(imageUrl);
        var blob = await res.blob();

        return new Promise((resolve, reject) => {
            var reader = new FileReader();
            reader.addEventListener("load", function () {
                resolve(reader.result);
            }, false);

            reader.onerror = () => {
                return reject(this);
            };
            reader.readAsDataURL(blob);
        })
    }

    convertJsonToValueStringArray(Data: any[]): any[][] {
        return ([...Data.map(x => Object.values(x))]);
    }

    convertJsonToKeyStringArray(Data: any[]): string[] {
        return ([...Object.keys(Data[0]).map(x => x)]);
    }

    generateImage(id: string) {
        var node: any = document.getElementById(id);
        htmlToImage.toPng(node).then(function (dataUrl) {
            var img = new Image();
          img.src = dataUrl;
          return img
        }).catch(function (error) {
            console.error('oops, something went wrong!', error);
        });
    }
}
