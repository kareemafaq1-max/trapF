import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Subject } from 'rxjs';
import { ErrorInterface } from '@modules/error.interface';
import { environment as env } from '@env/environment';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

export function HttpLoaderFactory(httpClient: HttpClient) {
  return new TranslateHttpLoader(httpClient);
}

@Injectable({
  providedIn: 'root',
})
export class SharedService {
  navHeight: number = 35;
  footerHeight: number = 36;
  otherLang: string = '';
  asideStatus: boolean = true;

  trapTitle: any;

  domainUrl: string = env.domainUrl;
  loading: boolean = false;
  pageDir: boolean = false;
  pageContentHeight: number = 0;

  constructor(
    private translate: TranslateService,
    private router: Router,
    private ngxUiLoaderService: NgxUiLoaderService
  ) {}

  getRole = () => localStorage.getItem('trap_role');

  // AoT requires an exported function for factories

  localeEvent = new Subject<string>();
  changeLocale(locale: string) {
    this.translate.use(locale);
    this.localeEvent.next(locale);
    this.pageDir = !this.pageDir;
  }

  // logout function
  logout() {
    console.log('vvvvvvvvvv');
    
    localStorage.removeItem('trap_token');
    // window.location.reload()
    if (!localStorage.getItem('trap_token')){
      this.router.navigateByUrl('/login');
    }
  }

  // handleError from request . .
  handleError(error: ErrorInterface) {
    if (error.code == 401 || error.code == 403) {
      localStorage.removeItem('trap_token');
      this.router.navigate(['/login'], {
        queryParams: { returnUrl: this.router.routerState.snapshot.url },
      });
    }
    this.ngxUiLoaderService.stopLoader('loader');
  }

  // handle error by message toast
  toastErrorHandler(error: any): Object {
    return {
      severity: 'error',
      key: 'backEnderror',
      summary: 'you Are Currently Offline',
      detail: error,
    };
  }
  toastSuccessRequest(message: any): Object {
    return {
      severity: 'success',
      summary: message,
    };
  }
  htmlToCanvasWithAppendFormData(
    ElementID: string,
    formData: FormData,
    title: string = ''
  ): Promise<Blob> {
    return new Promise((resolve, reject) => {
      let element1: any = document.getElementById(ElementID);
      html2canvas(element1, { useCORS: true })
        .then((canvas) => {

          // var img = document.createElement("img"); // create an image object
          //     img.src = canvas.toDataURL(); // get canvas content as data URI
          // document.body.appendChild(img);


          let data: Blob = this.dataURItoBlob(canvas.toDataURL('image/jpg'));
          formData.append('files', data);
          resolve(data);
        })
        .catch((e) => {
          reject(e);
        });
    });
  }

  dataURItoBlob(dataURI: string) {
    var byteString = atob(dataURI.split(',')[1]);
    var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
    var ab = new ArrayBuffer(byteString.length);
    var ia = new Uint8Array(ab);
    for (var i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    var blob = new Blob([ab], { type: mimeString });
    return blob;
  }

  async htmlToImage(
    stringID: string,
    pdf: jsPDF,
    x: number = 0,
    y: number = 0,
    width: number = 210
  ) {
    let DATA: any = document.getElementById(stringID);
    await html2canvas(DATA, { useCORS: true }).then((canvas) => {
      const FILEURI = canvas.toDataURL('image/png');
      pdf.addImage(
        FILEURI,
        'PNG',
        x,
        y,
        width,
        (canvas.height * width) / canvas.width
      );
    });
  }

  async htmlToImage2(
    stringID: string,
    pdf: jsPDF,
    x: number = 0,
    y: number = 0,
    width: number = 210
  ) {
    let DATA: any = document.getElementById(stringID);
    // DATA.classList.remove('d-none');
    await html2canvas(DATA, { useCORS: true }).then((canvas) => {
      const FILEURI = canvas.toDataURL('image/png');
      pdf.addImage(
        FILEURI,
        'PNG',
        x,
        y,
        width,
        (canvas.height * width) / canvas.width
      );
    });
  }
}
