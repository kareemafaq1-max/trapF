import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment as env } from '@env/environment';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import * as fs from 'file-saver';
import * as htmlToImage from 'html-to-image';

@Injectable({
  providedIn: 'root',
})
export class ReportService {
  baseURL: string = env.apiPath + 'Reports/';
  // baseURL: string = 'https://localhost:44367/api/Reports/';

  constructor(private http: HttpClient) {}

  getHomeReport(formData: FormData) {
    return this.http.post(this.baseURL + 'GetHomeReport', formData, {
      responseType: 'arraybuffer',
    });
  }

  getTrapDetailsReport(formData: FormData) {
    return this.http.post(this.baseURL + 'GetTrapDetailsReport', formData, {
      responseType: 'arraybuffer',
    });
  }

  GetTrapReport(id: number, formData: FormData) {
    return this.http.post(this.baseURL + 'GetTrapReport/' + id, formData, {
      responseType: 'blob',
    });
  }
}
