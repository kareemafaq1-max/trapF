import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Router, RouterStateSnapshot } from '@angular/router';
import { SharedService } from '@modules/shared.service';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  constructor(private _router: Router, private state: RouterStateSnapshot, private sharedService: SharedService) { }

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(
      catchError((error) => {
        if (error instanceof HttpErrorResponse) {
          if (error.status == 401) {
            localStorage.removeItem('trap_token');
            window.location.reload();
            // this._router.navigateByUrl('/login');
          }
          const applicationError = error.headers.get('Application-Error');
          if (applicationError) {
            
            return throwError(applicationError);
          }
          const ServerError: any[] = error.error?.errors || [];
          let errors: any[] = [];
          ServerError.forEach((err) => {
            errors = [...errors, ...err];
          });
          
          return throwError(
            {
              code: error.status,
              errors,
              message: error?.error.message
            } || 'serverError'
          );
        }
        return throwError('UnknownError');
      })
    );
  }
}
