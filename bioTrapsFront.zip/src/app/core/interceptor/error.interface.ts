export interface ErrorInterface {
  code: number;
  errors: string[];
  message: string;
}
