import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

export interface AppConfig {
  inputStyle: string;
  dark: boolean;
  theme: string;
  ripple: boolean;
}

@Injectable({
  providedIn: 'root',
})
export class PrimeNGService {
  constructor() {}

  config: AppConfig = {
    theme: 'lara-light-blue',
    dark: false,
    inputStyle: 'outlined',
    ripple: true,
  };

  configUpdate = new Subject();

  configUpdate$ = this.configUpdate.asObservable();

  // updateConfig(config:AppConfig) {
  //   this.config = config
  //   this.configUpdate.next(config)
  // }



  // Start Update Options
  updateBarChartOptions(barPercentage:string,stacked:boolean) {
    return {
      barPercentage,
      borderRadius: 7,
      plugins: {
          tooltips: {
              mode: 'index',
              intersect: false
          },
          legend: {
              labels: {
                  color: '#495057'
              }
          }
      },
      scales: {
          x: {
              stacked,
              ticks: {
                  color: '#495057'
              },
              grid: {
                color: '#ebedef',
              }
          },
          y: {
              stacked,
              ticks: {
                  color: '#495057'
              },
              grid: {
                  color: '#ebedef'
              }
          }
      }
  };
  }
  // End Update Options
}
