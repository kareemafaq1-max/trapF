import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '@modules/auth.guard';
import { BaseComponent } from '@modules/base/base.component';
import { ErrorPageComponent } from '@modules/error-page.component';

const routes: Routes = [
  {
    path: 'login',
    loadChildren: () =>
      import('@modules/auth.module').then((m) => m.AuthModule),
  },
  {
    path: '',
    component: BaseComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: '',
        loadChildren: () =>
          import('@modules/general.module').then((m) => m.GeneralModule),
      },
      { path: '**', component: ErrorPageComponent, pathMatch: 'full' },
    ],
  },
  { path: '**', component: ErrorPageComponent, pathMatch: 'full' },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      scrollPositionRestoration: 'top',
      useHash: true,
    }),
  ],
  exports: [RouterModule],
  providers: [{ provide: LocationStrategy, useClass: HashLocationStrategy }],
})
export class AppRoutingModule {}
