import { MessageService } from 'primeng/api';
import { AfterViewInit, Component, Inject, OnInit, PLATFORM_ID, Renderer2 } from '@angular/core';
import { merge, fromEvent, map, Observable, Observer } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import { SharedService } from '@modules/shared.service';
import { ActivatedRoute } from '@angular/router';
import { DOCUMENT, isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit, AfterViewInit {
  title = '';
  isBrowser!: boolean;
  constructor(
    private messageService: MessageService,
    public translate: TranslateService,
    public sharedService: SharedService,
    private route: ActivatedRoute,
    @Inject(PLATFORM_ID) private platformId: any,
    @Inject(DOCUMENT) private document: Document,
    private renderer: Renderer2,
  ) {
    this.isBrowser = isPlatformBrowser(platformId);
    this.translate.addLangs(['en', 'ar']);
    this.translate.setDefaultLang('ar');
    this.sharedService.trapTitle = "BIOTRAPS"
  }


  ngOnInit() {
    this.checkNetwork$.subscribe((isConnected) => {
      if (!isConnected) this.networkToast();
      else this.messageService.clear('network');
    });
  }


  // Check metwork connection (retrun true or false)
  checkNetwork$ = merge(
    fromEvent(window, 'offline').pipe(map(() => false)),
    fromEvent(window, 'online').pipe(map(() => true)),
    new Observable((sub: Observer<boolean>) => {
      sub.next(navigator.onLine);
      sub.complete();
    })
  );

  networkToast() {
    this.messageService.add({
      severity: 'warn',
      closable: false,
      key: 'network',
      sticky: true,
      summary: 'disconnected',
      detail: 'internet connection error...',
    });
  }

  ngAfterViewInit() {
    if (this.isBrowser) {
      setTimeout(() => {
        let loader = this.renderer.selectRootElement('#loader')
        const body = document.getElementsByTagName("body");
        this.renderer.setStyle(loader, 'display', 'none')
        body[0].style.overflowY = 'hidden'
      }, 2000)
    }
  }
}
