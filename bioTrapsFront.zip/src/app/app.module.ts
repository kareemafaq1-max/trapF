import { SharedModule } from '@modules/shared.module';
import { environment as env } from '@env/environment'
//Core
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//Components
import { AppComponent } from './app.component';
//Modules
import { AppRoutingModule } from './app-routing.module';
import { LayoutModule } from '@modules/layout.module';
import { AuthGuard } from '@modules/auth.guard';
import { FormsModule } from '@angular/forms';
import { InterceptorsProvider } from '@modules/index';
import { MessageService } from 'primeng/api';
import { NgxUiLoaderHttpModule, NgxUiLoaderModule, NgxUiLoaderRouterModule} from 'ngx-ui-loader';



@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    LayoutModule,
    SharedModule,
    FormsModule,
    // NgxUiLoaderModule.forRoot({ }),
    // NgxUiLoaderHttpModule.forRoot({
    //   loaderId: 'loader',
    //   showForeground: true,
    //   exclude: []
    // }),
    // NgxUiLoaderRouterModule.forRoot({loaderId:'loader'})
  ],
  providers: [InterceptorsProvider,AuthGuard,MessageService],
  exports:[NgxUiLoaderModule],
  bootstrap: [AppComponent],

})
export class AppModule { }
