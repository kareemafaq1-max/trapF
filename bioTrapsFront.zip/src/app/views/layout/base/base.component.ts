import {
  Event,
  NavigationCancel,
  NavigationEnd,
  NavigationError,
  NavigationStart,
  RouteConfigLoadEnd,
  RouteConfigLoadStart,
  Router,
  Event as RouterEvent,
} from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { MessageService } from 'primeng/api';
import { SharedService } from '@modules/shared.service';

@Component({
  selector: 'app-base',
  templateUrl: './base.component.html',
  styleUrls: ['./base.component.css'],
})
export class BaseComponent implements OnInit {
  isLoading: boolean = false;

  constructor(
    public sharedService: SharedService,
    public router: Router,
    public translate: TranslateService,
    public messageService: MessageService
  ) {
    
    // Spinner for lazyload modules
    // router.events.forEach((event) => {
    //   if (event instanceof RouteConfigLoadStart) this.isLoading = true;
    //   else if (event instanceof RouteConfigLoadEnd) this.isLoading = false;
    // });

    // Load the translation
    translate.addLangs(['ar', 'en']);
    translate.setDefaultLang('en');
    let defLang: string = localStorage.getItem('lang') ?? 'en';
    translate.use(defLang.toLowerCase());
    sharedService.pageDir = defLang == 'en' ? true : false;
  }

  ngOnInit() {
    if (window.innerWidth < 768) {
      this.sharedService.asideStatus = false;
    }
  }

  ngAfterViewInit() {
    this.router.events.subscribe((event: RouterEvent) => {
      if (event instanceof NavigationStart != event instanceof NavigationEnd) {
        this.navigationInterceptor(event);
        if (window.innerWidth < 768) {
          this.sharedService.asideStatus = false;
        }
      }
    });
  }

  // Shows and hides the loading spinner during RouterEvent changes
  navigationInterceptor(event: RouterEvent): void {
    if (event instanceof NavigationStart) {
      this.isLoading = false;
    }
    if (event instanceof NavigationEnd) {
      setTimeout(() => { // here
        this.isLoading = false;
      }, 1500);
    }
    if (event instanceof NavigationCancel) {
      setTimeout(() => { // here
        this.isLoading = false;
      }, 1500);
    }
    if (event instanceof NavigationError) {
      setTimeout(() => { // here
        this.isLoading = false;
      }, 1500);
    }
  }
}
