import { Component, OnInit } from '@angular/core';
import { SharedService } from '@modules/shared.service';

@Component({
  selector: 'app-horizontal',
  templateUrl: './horizontal.component.html',
  styleUrls: ['./horizontal.component.css']
})
export class HorizontalComponent implements OnInit {
  myRole: string = '';
  userName:string = '';
  constructor(public sharedService: SharedService) {
    this.myRole = localStorage.getItem('trap_role')!;
    this.userName = localStorage.getItem('userName')!;

  }

  ngOnInit(): void {
  }

}
