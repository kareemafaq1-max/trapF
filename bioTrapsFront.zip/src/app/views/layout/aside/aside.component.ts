import { ThisReceiver } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SharedService } from '@modules/shared.service';

@Component({
  selector: 'app-aside',
  templateUrl: './aside.component.html',
  styleUrls: ['./aside.component.css'],
})
export class AsideComponent implements OnInit {
  myRole: any;


  constructor(
    public sharedService: SharedService,
    public router: Router,
  ) {
    this.myRole = localStorage.getItem('trap_role')
  }

  ngOnInit() { }
}
