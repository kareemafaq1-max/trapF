import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@modules/shared.module';
import { BaseComponent } from './base/base.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FooterComponent } from './footer/footer.component';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { HttpLoaderFactory } from '@modules/shared.service';
import { LoaderComponent } from './loaders/loader/loader.component';
import { HomeLoaderComponent } from './loaders/home-loader/home-loader.component';
import { AsideComponent } from './aside/aside.component';
import { HorizontalComponent } from './horizontal/horizontal.component';
import { LoadingModule } from './loading/loading.module';


@NgModule({
  declarations: [BaseComponent, NavbarComponent, FooterComponent, LoaderComponent,AsideComponent,HomeLoaderComponent, HorizontalComponent],
  exports:[LoaderComponent,HomeLoaderComponent],
  imports: [
    CommonModule,
    SharedModule,
    HttpClientModule,
    LoadingModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    })
  ],
})
export class LayoutModule { }
