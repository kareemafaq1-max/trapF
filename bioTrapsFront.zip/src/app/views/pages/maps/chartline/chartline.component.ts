import { Component, Input, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

export type ChartOptions = {
  series: any;
  chart: any;
  xaxis: any;
  stroke: any;
  dataLabels: any;
  markers: any;
  tooltip: any; // ApexTooltip;
  yaxis: any;
  grid: any;
  legend: any;
  title: any;
};

export const chartOptions = {
  series: [
    {
      name: "Small Mosuqitoes (Total:150)",
      data: [ ]
    },
    {
      name: "Large Mosuqitoes (Total:120)",
      data: [ ]
    },
    {
      name: "Mosuqitoes (Total:544)",
      data: [ ]
    }
  ],
  colors: ['#2E93fA', '#66DA26', '#546E7A', '#E91E63', '#FF9800'],
  chart: {
    height: 350,
    type: "line"
  },
  dataLabels: {
    enabled: false
  },
    tension: 100,
  stroke: {
    width: 5,
    curve: "smooth",
    dashArray: [0, 0, 0],
   },
  title: {
    text: "",
    align: "left"
  },
  markers: {
    size: 0,
    hover: {
      sizeOffset: 6
    }
  },
  xaxis: {
    // reversed: true,
    labels: {
      trim: false
    },
    categories: []
  },
  tooltip: {
    y: [
      {
        title: {
          formatter: function (val: any) {
            return val;
          }
        }
      },
      {
        title: {
          formatter: function (val: any) {
            return val;
          }
        }
      },
      {
        title: {
          formatter: function (val: any) {
            return val;
          }
        }
      }
    ]
  },
  grid: {
    borderColor: "#f1f1f1"
  },
  yaxis: {

  }
};

@Component({
  selector: 'app-chartline',
  templateUrl: './chartline.component.html',
  styleUrls: ['./chartline.component.css']
})
export class ChartlineComponent implements OnInit {

  @Input() AllData: Observable<any> = new Observable();
  chartOptions: Partial<ChartOptions> = {};

  constructor() {
    this.chartOptions = { ...chartOptions }
  }

  ngOnInit() {
    this.AllData.subscribe((res) => {
      this.chartOptions.series = [];
      this.chartOptions.xaxis = {}
      this.chartOptions.xaxis = { categories: [...res.labels] }
      this.chartOptions.xaxis.categories = res.labels;
      this.chartOptions.series = res.series;
    });


  }

}
