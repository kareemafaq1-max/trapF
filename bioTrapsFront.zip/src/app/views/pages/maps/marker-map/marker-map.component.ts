import { Router } from '@angular/router';
import {
  AfterViewInit,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  Pipe,
  PipeTransform,
  SimpleChanges,
  ViewChild,
  ViewChildren,
} from '@angular/core';
import { GoogleMap, MapInfoWindow, MapMarker } from '@angular/google-maps';
import { faCircle } from '@fortawesome/free-solid-svg-icons';
import { Read } from '@modules/interfaces/trap-interface';
import { Observable, Subscription } from 'rxjs';

@Component({
  selector: 'app-marker-map',
  templateUrl: './marker-map.component.html',
  styleUrls: ['./marker-map.component.css'],
})
export class MarkerMapComponent implements OnInit, OnChanges, AfterViewInit {
  @Output() reloadByTrapId:EventEmitter<any> = new EventEmitter();
  @ViewChildren(MapInfoWindow) infoWindow: any;
  @ViewChild(MapInfoWindow) infoWindowDetails!: MapInfoWindow;
  infoPosition: google.maps.LatLngLiteral = { lat: -34.397, lng: 150.644 };
  // infoOptions: google.maps.InfoWindowOptions = {};
  // infoPosition: google.maps.LatLngLiteral = { lat: -34.397, lng: 150.644 };
  @ViewChild(GoogleMap) map!: GoogleMap;
  @Input() AllData!: Observable<any>;
  @Input() trapDetail!: any[];
  @Input() single: boolean = false;
  // get data from parent
  allData: any = [];
  allDataSub: Subscription = new Subscription();
  markerColor = '';
  mapStyle: google.maps.MapTypeStyle[] = [
    {
      featureType: 'administrative',
      elementType: 'geometry',
      stylers: [
        {
          visibility: 'off',
        },
      ],
    },
    {
      featureType: 'administrative.land_parcel',
      stylers: [
        {
          visibility: 'off',
        },
      ],
    },
    {
      featureType: 'administrative.neighborhood',
      stylers: [
        {
          visibility: 'off',
        },
      ],
    },
    {
      featureType: 'administrative.province',
      elementType: 'geometry',
      stylers: [
        {
          visibility: 'off',
        },
      ],
    },
    {
      featureType: 'poi',
      stylers: [
        {
          visibility: 'off',
        },
      ],
    },
    {
      featureType: 'poi',
      elementType: 'labels.text',
      stylers: [
        {
          visibility: 'off',
        },
      ],
    },
    {
      featureType: 'poi.attraction',
      stylers: [
        {
          visibility: 'off',
        },
      ],
    },
    {
      featureType: 'poi.business',
      stylers: [
        {
          visibility: 'off',
        },
      ],
    },
    {
      featureType: 'road',
      stylers: [
        {
          visibility: 'off',
        },
      ],
    },
    {
      featureType: 'road',
      elementType: 'labels',
      stylers: [
        {
          visibility: 'off',
        },
      ],
    },
    {
      featureType: 'road',
      elementType: 'labels.icon',
      stylers: [
        {
          visibility: 'off',
        },
      ],
    },
    {
      featureType: 'road.highway',
      stylers: [
        {
          visibility: 'off',
        },
      ],
    },
    {
      featureType: 'transit',
      stylers: [
        {
          visibility: 'off',
        },
      ],
    },
    {
      featureType: 'transit.line',
      stylers: [
        {
          visibility: 'off',
        },
      ],
    },
    {
      featureType: 'transit.station',
      stylers: [
        {
          visibility: 'off',
        },
      ],
    },
    {
      featureType: 'water',
      elementType: 'labels.text',
      stylers: [
        {
          visibility: 'off',
        },
      ],
    },
  ];
  valueCo2 = 25;
  valueQut = 75;
  markers = [];
  center: google.maps.LatLngLiteral = {
    lat: 24.718694510120354,
    lng: 46.68111315541776,
  };
  zoom = 5;

  options: google.maps.MapOptions = {
    zoomControl: true,
    scrollwheel: false,
    disableDoubleClickZoom: true,
    styles: this.mapStyle,
    gestureHandling: 'cooperative',
  };
  polylineOptions: google.maps.PolylineOptions = {
    path: [],
    strokeColor: '#f00',
    strokeOpacity: 1.0,
    strokeWeight: 2,
  };
  markerOptions:any = {
    animationDROP: google.maps.Animation.DROP,
    animationBOUNCE: google.maps.Animation.BOUNCE,
  };

  constructor(private route: Router) {

  }

  ngOnInit(): void {
    // this.getTrap();
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.getTrap();
    this.trapDetail?.forEach((ele: any) => {
      this.center = { lat: +ele.lat, lng: +ele.long };
      this.allData.push({
        markerPosition: { lat: +ele.lat, lng: +ele.long },
      });
    });
  }
  getTrap() {
    if (this.single) {
      this.zoom = 12;
    }
    this.allDataSub = this.AllData?.subscribe((res: any) => {
      if (this.route.url == '/') {
        res.data?.forEach((ele: any) => {
          // this.center = { lat: +ele.lat, lng: +ele.long };
          this.allData.push({
            markerPosition: { lat: +ele.lat, lng: +ele.long },
            trapId: ele.trapId,
            trapName: ele.trapName,
            serlNum: ele.serialNumber,
            readingDate: ele.readingDate,
            readingTime: ele.readingTime,
            powerDraw: ele.powerDraw,
            counter: ele.counter,
            valveQut: ele.valveQut,
            fan:ele.fan,
            isThereEmergency: ele.isThereEmergency
          });
        });
      }
      if (this.route.url.startsWith('/yourTraps')) {
        let trap = [res];
        // if (this.single) {
        //   this.openInfoWindowAtMarker()
        // }
        trap.forEach((ele: any) => {
          this.center = { lat: +ele.lastLat, lng: +ele.lastLong };
          this.infoPosition = this.center;
          this.allData.push({
            markerPosition: { lat: +ele.lastLat, lng: +ele.lastLong },
            trapId: ele.trapId,
            trapName: ele.trapName,
            serlNum: ele.serialNumber,
            readingDate: ele.readingDate,
            readingTime: ele.readingTime,
            powerDraw: ele.powerDraw,
            counter: ele.counter,
            valveQut: ele.valveQut,
            isThereEmergency: ele.isThereEmergency
          });
        });
      }
      if (this.route.url.includes('emergency')) {
        this.zoom = 18;
        let path: any = [];
        res.forEach((ele: any, index: number) => {
          // if (ele.lat && ele.long && !checkPostion) {
            // }
            if (+ele.lat && +ele.long){
              this.allData.push({
                markerPosition: { lat: +ele.lat, lng: +ele.long },
                date: ele.date,
              });
              path.push({ lat: +ele.lat, lng: +ele.long })
              this.center = { lat: +ele.lat, lng: +ele.long };
            }
        });
        // this.polylineOptions.path = path;
        this.polylineOptions = { ...this.polylineOptions, path };
        // this.center = { lat: +res[0]?.lat, lng: +res[0]?.long };
      }

    });

  }
  openInfoWindow(marker: any, i: any) {
    this.close_window();
    let list = [...this.infoWindow];
    list[i].open(marker);
  }
  openInfoWindowAtMarker() {
    setTimeout(() => {
      this.infoWindowDetails.open();
    }, 1000);
  }
  close_window() {
    let list = [...this.infoWindow];
    list.forEach((element) => {
      element.close();
    });
  }
  ngAfterViewInit(): void {

  }
  icon(data: any): any {
    let url = '';
    if (this.route.url.includes('emergency')) {
      url = 'assets/icons/red.png'
    } else {
      url = data.counter == 1 && !data.isThereEmergency ? 'assets/icons/green.png' :
        data.isThereEmergency ? 'assets/icons/red.png' : 'assets/icons/gray.png';
    }
    let icon = {}
    icon = {
      url: url,
      scaledSize: new google.maps.Size(32, 32),
      size: new google.maps.Size(64, 64),
      scale: (this.zoom / 100) * 0.7,
    }
    return icon
  }
}


@Pipe({
  name: 'iconMap'
})
export class iconMapPipe implements PipeTransform {
  constructor(private route: Router) {

  }
  transform(value: string): string {
    if (!value) return value; // Handle null or undefined values
    
    return this.icon(value);
  }
  icon(data: any): any {
    let url = '';
    let icon = {};
    if (this.route.url.includes('emergency')) {
      url = 'assets/icons/red.png'
    } else {
      url = data.counter == 1 && !data.isThereEmergency ? 'assets/icons/green.png' :
        data.isThereEmergency ? 'assets/icons/red.png' : 'assets/icons/gray.png';
    }
    icon = {
      url: url,
      scaledSize: new google.maps.Size(32, 32),
      // size: new google.maps.Size(64, 64),
      // scale: (this.zoom / 100) * 0.7,
    }
    return icon
  }
}