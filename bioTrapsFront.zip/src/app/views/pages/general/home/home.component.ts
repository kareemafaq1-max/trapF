import { Component, OnInit, ViewChild } from '@angular/core';
import { GenerateExcel } from '@modules/GenerateExcel';
import { ErrorInterface } from '@modules/error.interface';
import { ReportService } from '@modules/report.service';
import { SharedService } from '@modules/shared.service';
import { Read, ReadAdmin, ReadData, Statistcs, Trap } from '@modules/trap-interface';
import { TrapService } from '@modules/trap.service';
import { Workbook } from 'exceljs';
// import { ChartOptions } from 'chart.js';
import jsPDF from 'jspdf';
import * as fs from 'file-saver';
import { MessageService } from 'primeng/api';
import { Subject, Subscription } from 'rxjs';
import { DatePipe } from '@angular/common';
import html2canvas from 'html2canvas';
import * as fileS from 'file-saver';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  isLastReadMapLoading: boolean = false;
  // send data to map
  MapData: Subject<any> = new Subject<any>();
  trapIdChart1: number = 0;
  statistcsForTrapReadingsAsInsects: any;
  statistcs: any;
  Exportloading: boolean = false;

  allTraps: Trap[] = [];
  allData: any = [];
  allDataSub: Subscription = new Subscription();
  lastReadTrapsData: ReadData[] = [];
  LastReadForTrap: any;
  // charts
  lastReadingForAllTraps: any[] = [];
  chartOptions2: any;
  mosuqitoesPerMonth: any;
  listOfTraps: any[] = [];
  countOfMosuqitoesPerSevenDaysMosuqitoes: any[] = [];
  statisticsForAllTrapsReadingsAsInsects: any[] = [];
  countOfMosuqitoesPerSevenDaysFly: any[] = [];
  countOfMosuqitoesToLast12Months: any[] = [];
  myRole: any;
  title: string = '';
  trapName: string = '';
  trapId: number = 0;
  loadingExportExcel: boolean = false;
  constructor(
    public sharedService: SharedService,
    private reportService: ReportService,
    private trapService: TrapService,
    private messageService: MessageService
  ) {
    this.myRole = localStorage.getItem('trap_role');

    this.chartOptions2 = {
      plotOptions: {
        pie: {
          donut: {
            labels: {
              show: true,
              total: {
                showAlways: true,
                show: true
              }
            }
          }
        }
      },
      series: [
        {
          name: "Inflation",
          data: [3, 1, 5, 1, 5, 6]
        }
      ],
      chart: {
        height: '300px',
        width: '100%',
        type: "bar"
      },
      // plotOptions: {
      //   bar: {
      //     dataLabels: {
      //       position: "top" // top, center, bottom
      //     }
      //   }
      // },
      dataLabels: {
        enabled: true,
        formatter: function (val: any) {
          return val + "%";
        },
        offsetY: -20,
        style: {
          fontSize: "12px",
          colors: ["#304758"]
        }
      },

      xaxis: {
        categories: [
          "Jan",
          "Feb",
          "Mar",
          "Apr",
          "May",
          "Jun",
        ],
        position: "top",
        labels: {
          offsetY: -18
        },
        axisBorder: {
          show: false
        },
        axisTicks: {
          show: false
        },
        crosshairs: {
          fill: {
            type: "gradient",
            gradient: {
              colorFrom: "#D8E3F0",
              colorTo: "#BED1E6",
              stops: [0, 100],
              opacityFrom: 4,
              opacityTo: 5
            }
          }
        },
        tooltip: {
          enabled: true,
          offsetY: -35
        }
      },
      // fill: {
      //   type: "gradient",
      //   gradient: {
      //     shade: "light",
      //     type: "horizontal",
      //     shadeIntensity: 0.25,
      //     gradientToColors: undefined,
      //     inverseColors: true,
      //     opacityFrom: 1,
      //     opacityTo: 1,
      //     stops: [50, 0, 100, 100]
      //   }
      // },
      yaxis: {
        axisBorder: {
          show: false
        },
        axisTicks: {
          show: false
        },
        labels: {
          show: false,
          formatter: function (val: any) {
            return val + "%";
          }
        }
      },
      title: {
        text: "Monthly Inflation in Argentina, 2002",
        floating: 0,
        offsetY: 320,
        align: "center",
        style: {
          color: "#444"
        }
      }
    };
  }
  listOfCountOfMosuqitoesInDayOfMonthOfYear: any[] = []
  ngOnInit() {
    this.ListOfTraps();
    this.getLastReadForTraps();
    this.getNumberOfTrapsOnly()
    this.getAllTraps();
    this.GetLastReadingForAllTraps();
    // this.myRole == 'SuperAdmin' ?  this.GetLastReadingForAllTraps() : null;
    this.GetStatisticsForAllTrapsReadingsAsInsects();
    this.GetCountOfMosuqitoesPerSevenDaysMosuqitoes();
    this.GetCountOfMosuqitoesPerSevenDaysFly();
    this.GetCountOfMosuqitoesToLast12Months();
    this.GetCountOfMosuqitoesPerMonth();
    this.GetCountOfMosuqitoesInDayOfMonthOfYear();

  }

  getTrapFromMap(event: any) {
    this.title = event.name
  }
  getLastReadForTraps() {
    this.isLastReadMapLoading = true;
    this.trapService.GetLastReadForTraps().subscribe(
      (res) => {
        this.isLastReadMapLoading = true;
        this.MapData.next(res);
        this.MapData.complete();
      },
      (error: ErrorInterface) => {
        this.isLastReadMapLoading = false;
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      },
      () => {
        this.isLastReadMapLoading = false;
        // let newArray = this.lastReadTrapsData;
        // for (let i = 0; i < this.allTraps.length; i++) {
        //   for (let j = 0; j < newArray.length; j++) {
        //     if (this.allTraps[i].id == newArray[j].trapId) {
        //       this.allTraps[i].customReading = newArray[j].readingDate;
        //       this.allTraps[i].lastLat = newArray[j].lat;
        //       this.allTraps[i].lastLong = newArray[j].long;
        //       this.allTraps[i].customReadintTime = newArray[j].readingTime;
        //       newArray.splice(i, 1);
        //       break;
        //     }
        //   }
        //   if (newArray.length < 1) {
        //     break;
        //   }
        // }
      }
    );
  }
  getNumberOfTrapsOnly() {
    this.trapService.GetNumberOfTrapsOnly().subscribe({
      next: (res: any) => {
        this.statistcs = res.data;
      },
      error: (error: ErrorInterface) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      }
    })
  }
  ListOfTraps() {
    this.trapService.ListOfTraps().subscribe(
      (res: any) => {
        this.listOfTraps = res.data.data;
        this.trapIdChart1 = this.listOfTraps[0].id;
        // this.GetStatisticsForTrapReadingsAsInsects();
      },
      (error: ErrorInterface) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      },
      () => {
      }
    );
  }
  GetStatisticsForTrapReadingsAsInsects() {
    this.trapService.GetStatisticsForTrapReadingsAsInsects(this.trapIdChart1).subscribe({
      next: (res: any) => {
        this.statistcsForTrapReadingsAsInsects = res.data;
      },
      error: (error: ErrorInterface) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      }
    })
  }
  GetStatisticsForAllTrapsReadingsAsInsects() {
    this.trapService.GetStatisticsForAllTrapsReadingsAsInsects().subscribe({
      next: (res: any) => {
        this.statisticsForAllTrapsReadingsAsInsects = res.data;
      },
      error: (error: ErrorInterface) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      }
    })
  }

  GetCountOfMosuqitoesInDayOfMonthOfYear() {
    // this.trapService.GetCountOfMosuqitoesInDayOfMonthOfYear({}).subscribe({
    //   next: (res: any) => {
    //     this.listOfCountOfMosuqitoesInDayOfMonthOfYear = res.data;
    //   },
    //   error: (error: ErrorInterface) => {
    //     this.sharedService.handleError(error);
    //     this.messageService.add(this.sharedService.toastErrorHandler(error.message));
    //   }
    // })
  }

  getAllTraps() {
    this.trapService.GetAllTraps().subscribe(
      (res: any) => {
        this.allTraps = res.data;
      },
      (error: ErrorInterface) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      },
      () => { }
    );
  }

  GetLastReadingForAllTraps() {
    this.trapService.GetLastReadingForAllTraps().subscribe(
      (res: any) => {
        this.lastReadingForAllTraps = res.data.sort((a: any, b: any) => {
          // Compare readingDate
          if (a.readingDate > b.readingDate) return -1;
          if (a.readingDate < b.readingDate) return 1;

          // If readingDate is the same, compare readingTime
          const timeA = a.readingTime.split(':').map(Number);
          const timeB = b.readingTime.split(':').map(Number);
          if (timeA[0] > timeB[0]) return -1;
          if (timeA[0] < timeB[0]) return 1;
          if (timeA[1] > timeB[1]) return -1;
          if (timeA[1] < timeB[1]) return 1;
          return 0;
        });

      },
      (error: ErrorInterface) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      },
      () => { }
    );
  }

  async exportpdf() {
    this.Exportloading = true;
    let PDF = new jsPDF('p', 'mm', 'a4');
    await this.sharedService.htmlToImage('logo', PDF, 2, 2, 25);
    PDF.text('Report', 100, 16);

    PDF.text('Traps : ' + this.statistcs.numberOfTraps + '', 20, 32);
    if (this.sharedService.getRole() == 'SuperAdmin') {
      PDF.text('Users : ' + this.statistcs.numberOfUsers + '', 65, 32);
    }
    PDF.text(
      'Working : ' + this.statistcs.numberOfWorking + '',
      105,
      32
    );
    PDF.text(
      'Not ActiveTraps : ' + this.statistcs.numberOfNotWorking + '',
      150,
      32
    );

    // await this.sharedService.htmlToImage2('data', PDF, 0, 28);
    await this.sharedService.htmlToImage('titlehomeMap1', PDF, 0, 35);
    await this.sharedService.htmlToImage('homeMap1', PDF, 0, 42);
    PDF.save('Main Report.pdf');
    this.Exportloading = false;
  }

  async exportWord() {
    try {
      this.Exportloading = true;
      let formData = new FormData();
      await this.sharedService.htmlToCanvasWithAppendFormData('logo', formData);
      await this.addFormData(formData);

      this.reportService
        .getHomeReport(formData)
        .subscribe((res: ArrayBuffer) => {
          const byteArray = new Uint8Array(res);
          const url = window.URL.createObjectURL(new Blob([byteArray]));
          const link = document.createElement('a');
          link.href = url;
          link.setAttribute('download', 'Report.docx');
          document.body.appendChild(link);
          link.click();
        });
      this.Exportloading = false;
    } catch (err) {
      this.Exportloading = false;
    }
  }

  async addFormData(formData: FormData) {
    await this.sharedService.htmlToCanvasWithAppendFormData(
      'homeMap1',
      formData,
      'Traps Today Read,' +
        this.statistcs.numberOfTraps +
        ',' +
        this.sharedService.getRole() ==
        'SuperAdmin'
        ? this.statistcs.numberOfUsers + ','
        : '' +
        this.statistcs.numberOfWorking +
        ',' +
        this.statistcs.numberOfNotWorking
    );
  }

  // charts
  GetCountOfMosuqitoesPerMonth() {
    this.trapService.GetCountOfMosuqitoesPerMonth().subscribe({
      next: (res: any) => {
        this.mosuqitoesPerMonth = res.data
      }
    })
  }

  GetCountOfMosuqitoesToLast12Months() {
    this.trapService.GetCountOfMosuqitoesToLast12Months().subscribe({
      next: (res: any) => {
        this.countOfMosuqitoesToLast12Months = res.data
      }
    })
  }

  GetCountOfMosuqitoesPerSevenDaysMosuqitoes() {
    this.trapService.GetCountOfMosuqitoesPerSevenDays(true).subscribe({
      next: (res: any) => {
        this.countOfMosuqitoesPerSevenDaysMosuqitoes = res.data
      }
    })
  }

  GetCountOfMosuqitoesPerSevenDaysFly() {
    this.trapService.GetCountOfMosuqitoesPerSevenDays(false).subscribe({
      next: (res: any) => {
        this.countOfMosuqitoesPerSevenDaysFly = res.data
      }
    })
  }

  refreshData() {
    this.GetLastReadingForAllTraps();
  }

  // Start Export
  async exportExcel() {
    var datePipe = new DatePipe("en-US");
    if (this.lastReadingForAllTraps.length > 0) {
      const excel = new GenerateExcel();
      const workbook = new Workbook();
      const worksheet = workbook.addWorksheet('Sharing Data');
      // Add Row and formatting
      worksheet.addRow([]);
      // const titleRow1 = worksheet.addRow([
      //   'Recent Traps',
      // ]);
      // excel.headStyle1(titleRow1);
      excel.mergeCell('A2:C3', worksheet);
      //Add Image
      await excel
        .getBase64ImageFromUrl('assets/img/logo.png')
        .then((dataUrl: any) => {
          let logo = workbook.addImage({ base64: dataUrl, extension: 'png' });
          worksheet.addImage(logo, 'R1:R5');
        });
      worksheet.addRow([]);
      // Add Row and formatting
      const titleRow = worksheet.addRow(['Recent Traps']);
      excel.headStyle2(titleRow);
      excel.mergeCell('A5:R6', worksheet);
      //Add Content
      worksheet.addRow([]);
      worksheet.addRow([]);
      // Add Header Row
      const headerRow = worksheet.addRow([
        'Trap Name',
        'Date',
        'Time',
        // 'Small Mosuqitoes',
        // 'Large Mosuqitoes',
        // 'Mosuqitoes',
        // 'Other',
        // 'Counter',
        // 'Fan',
        // 'valve Qut',
        'Latitude',
        'Longitude',
      ]);

      // Cell Style : Fill and Border
      excel.tableHeadStyle1(headerRow);
      // Add Data and Conditional Formatting
      this.lastReadingForAllTraps.forEach((d: any) => {
        let row = worksheet.addRow([
          d.trapName,
          datePipe.transform(d.readingDate, "yyyy-MM-dd"),
          d.readingTime,
          // d.readingDate,
          // d.readingsmall,
          // d.readingLarg,
          // d.readingMosuqitoes,
          // d.readingFly,
          // d.counter ? 'On' : 'Off',
          // d.fan,
          // d.valveQut,
          d.lat,
          d.long,
        ]);
        row.alignment = { vertical: 'middle', horizontal: 'center' };
      });

      worksheet.columns.forEach((column, index) => {
        column.width = 15;
      });
      workbook.xlsx.writeBuffer().then((data: any) => {
        const blob = new Blob([data], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        fs.saveAs(blob, 'Recent_Traps_' + datePipe.transform(new Date(), "yyyy-MM-dd") + '.xlsx');
      });
    } else console.log('NO Rows Found');
  }

  filterByTrapId(trapId: any , el: HTMLElement) {
    this.trapId = trapId;
    this.trapName = this.allTraps.find((trap:any) => trap.id ==  trapId)?.name || '';
    this.GetStatisticsForAllTrapsReadingsAsInsectsById();
    this.GetCountOfMosuqitoesToLastSixMonthsForTrap();
    this.GetCountOfMosuqitoesTo12MonthsForSpecificTrap();
    this.GetCountOfMosuqitoesPerSevenDaysForSpecificTrapMosuqitoes();
    this.GetCountOfMosuqitoesPerSevenDaysForSpecificTrapFly();

    el.scrollIntoView({ behavior: 'smooth' });

  }

  // chart by trap id
  GetStatisticsForAllTrapsReadingsAsInsectsById() {
    this.trapService.GetStatisticsForTrapReadingsAsInsects(this.trapId).subscribe({
      next: (res: any) => {
        this.statisticsForAllTrapsReadingsAsInsects = res.data;
      }
    })
  }

  GetCountOfMosuqitoesToLastSixMonthsForTrap() {
    this.trapService.GetCountOfMosuqitoesToLastSixMonthsForTrap(this.trapId).subscribe({
      next: (res: any) => {
        this.mosuqitoesPerMonth = res.data
      }
    })
  }

  GetCountOfMosuqitoesTo12MonthsForSpecificTrap() {
    this.trapService.GetCountOfMosuqitoesTo12MonthsForSpecificTrap(this.trapId).subscribe({
      next: (res: any) => {
        this.countOfMosuqitoesToLast12Months = res.data
      }
    })
  }

  GetCountOfMosuqitoesPerSevenDaysForSpecificTrapMosuqitoes() {
    this.trapService.GetCountOfMosuqitoesPerSevenDaysForSpecificTrap(this.trapId, true).subscribe({
      next: (res: any) => {
        this.countOfMosuqitoesPerSevenDaysMosuqitoes = res.data
      }
    })
  }

  GetCountOfMosuqitoesPerSevenDaysForSpecificTrapFly() {
    this.trapService.GetCountOfMosuqitoesPerSevenDaysForSpecificTrap(this.trapId, false).subscribe({
      next: (res: any) => {
        this.countOfMosuqitoesPerSevenDaysFly = res.data
      }
    })
  }

  async onImg() {
    return new Promise((resolve, reject) => {
      html2canvas(document.getElementById(`charts`)!, {
        useCORS: true,
        allowTaint: false,
      }).then((canvas) => {
        canvas.toBlob(async (blob: any) => {
          let file = await new File([blob], `1.png`, { type: "image/png" });
          let reader = new FileReader();
          reader.onload = () => {
            let base64Data = reader.result;
            resolve(base64Data);
          };
          reader.readAsDataURL(file);
        }, 'image/png');
      }).catch((error) => {
        reject(error);
      });
    });
  }

  async exportExcelChart() {
    this.loadingExportExcel = true;
    const url: any = await this.onImg()
    const excel = new GenerateExcel();
    const workbook = new Workbook();

    const worksheet = workbook.addWorksheet('trap details', {
      // views: [{ state: 'frozen', xSplit: 4, ySplit: 9, rightToLeft: true }],
    });

    await excel.getBase64ImageFromUrl(url).then((dataUrl: any) => {
      let img = new Image();
      img.src = dataUrl;
      img.onload = () => {
        let width = img.width;
        let chart = workbook.addImage({ base64: dataUrl, extension: 'png' });
        worksheet.addImage(chart, {
          tl: { col: 8, row: 4 },
          ext: { width: width, height: 1300 }
        });
      };
    });

    workbook.xlsx.writeBuffer().then((data: any) => {
      const blob = new Blob([data], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });
      fileS.saveAs(blob, `Report Trap ${this.trapId ? this.trapId : ''}` + '.xlsx');
    });
    this.loadingExportExcel = false;
  }
}
