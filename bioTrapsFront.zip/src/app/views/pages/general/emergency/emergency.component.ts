import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ErrorInterface } from '@modules/error.interface';
import { TrapService } from '@modules/services/trap.service';
import { SharedService } from '@modules/shared.service';
import { MessageService } from 'primeng/api';
import { BehaviorSubject, Subject } from 'rxjs';

@Component({
  selector: 'app-emergency',
  templateUrl: './emergency.component.html',
  styleUrls: ['./emergency.component.css']
})
export class EmergencyComponent implements OnInit {
  MapData: Subject<any> = new Subject<any>();
  Data: BehaviorSubject<any> = new BehaviorSubject<any>([]);
  data$ = this.Data.asObservable();
  loading: boolean = false;
  expanded: boolean = false;
  loadingEmergencies: boolean = false;
  displayDialog: boolean = false;
  loadingEmergencybyDate: boolean = false;
  allData: any[] = [];
  serialNum: string = '';
  query:{
    serialNumber : string,
    month : Number,
    year : Number,
  } = {
    serialNumber : '',
    month : 0,
    year : 0,
  };
  emergencyDate:any[]=[];
  dataTrapEmergency:Subject<any> = new Subject<any>();
  constructor(
    private _ActivatedRoute: ActivatedRoute,
    private trapService: TrapService,
    private route: ActivatedRoute,
    public sharedService: SharedService,
    private messageService: MessageService

  ) {
    this._ActivatedRoute.paramMap.subscribe((param: any) => {
      this.serialNum = param.params['id'];
      this.query.serialNumber = this.serialNum;
      this.gedDateEmergency();
      this.getTrap();
    })
  }

  ngOnInit(): void {
  }

  gedDateEmergency(){
    const query:any = {
      serialNumber: this.serialNum ,
      EmergenciesGroupByYear: true
    }
    this.trapService.GetTrapEmergencies(query).subscribe(
      (res: any) => {
        this.emergencyDate = res.data
      },
      (error: ErrorInterface) => {
        this.sharedService.handleError(error);
        error.errors.forEach((err) => {
          this.messageService.add(this.sharedService.toastErrorHandler(err));
        });
      }
    );
  }

  getTrap() {
    this.loadingEmergencies = true;
    this.trapService.GetTrapEmergencies(this.query).subscribe(
      (res: any) => {

        let allList: any[] = res.data.map((item: any) => ({ year: item.date?.slice(0, 7), month: item.date?.split('-')[1], ...item }));
        this.Data.next(res.data.map((item: any) => ({ year: item.date?.slice(0, 7), month: item.date?.split('-')[1], ...item })));
        // // this.getUniqueBymonth(this.Data.value).then(x => this.Data.next(x))
        // this.uniqe().forEach((ele: any) => {
        //   this.allData.push({
        //     year: ele,
        //     list: allList.filter((val => val.year == ele))
        //   })
        // })
        
        this.MapData.next(this.Data.value);
        this.MapData.complete();
        this.loadingEmergencies = false;
      },
      (error: ErrorInterface) => {
        this.loadingEmergencies = false;
        this.sharedService.handleError(error);
        error.errors.forEach((err) => {
          this.messageService.add(this.sharedService.toastErrorHandler(err));
        });
      }
    );
  }

  
  getTrapBymounth(year:number , month:number) {
    // if(this.query.year == year , this.query.month == month){
    //   return
    // }
    // this.dataTrapEmergency.next([]);
    this.query.year = year;
    this.query.month = month;

    this.loadingEmergencybyDate = true;
    this.trapService.GetTrapEmergencies(this.query).subscribe(
      (res: any) => {
        this.dataTrapEmergency.next(res.data);
        this.loadingEmergencybyDate = false;
      },
      (error: ErrorInterface) => {
        this.loadingEmergencybyDate = false;
        this.sharedService.handleError(error);
        error.errors.forEach((err) => {
          this.messageService.add(this.sharedService.toastErrorHandler(err));
        });
      }
    );
  }

  uniqe(): any[] {
    return [...new Set(this.Data.value.map((item: any) => item.date?.slice(0, 7)))];
  }

  async getUniqueBymonth(data: any[]): Promise<any[]> {
    const uniqueDates: any = {};

    for (const key in data) {
      if (data.hasOwnProperty(key)) {
        const entry = data[key];
        uniqueDates[entry.month] = entry;
      }
    }

    const uniqueArray = await Object.values(uniqueDates);
    return uniqueArray;
  }
}
@Pipe({
  name: 'split'
})
export class SplitPipe implements PipeTransform {
  transform(val?: string): string {
    if (val) {
      return val.split('')[1];
    } else {
      return ''
    }

  }
}