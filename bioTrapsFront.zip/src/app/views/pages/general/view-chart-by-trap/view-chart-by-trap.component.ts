import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { GenerateExcel } from '@modules/GenerateExcel';
import { TrapService } from '@modules/services/trap.service';
import { SharedService } from '@modules/shared.service';
import { Workbook } from 'exceljs';
import html2canvas from 'html2canvas';
import * as fileS from 'file-saver';

@Component({
  selector: 'app-view-chart-by-trap',
  templateUrl: './view-chart-by-trap.component.html',
  styleUrls: ['./view-chart-by-trap.component.css']
})
export class ViewChartByTrapComponent implements OnInit {
  mosuqitoesPerMonth: any;
  countOfMosuqitoesPerSevenDaysMosuqitoes: any[] = [];
  statisticsForAllTrapsReadingsAsInsects: any[] = [];
  countOfMosuqitoesPerSevenDaysFly: any[] = [];
  countOfMosuqitoesToLast12Months: any[] = [];
  trapId: number = 0;
  chartOptions2 = {
    plotOptions: {
      pie: {
        donut: {
          labels: {
            show: true,
            total: {
              showAlways: true,
              show: true
            }
          }
        }
      }
    },
    series: [
      {
        name: "Inflation",
        data: [3, 1, 5, 1, 5, 6]
      }
    ],
    chart: {
      height: '300px',
      width: '100%',
      type: "bar"
    },
    // plotOptions: {
    //   bar: {
    //     dataLabels: {
    //       position: "top" // top, center, bottom
    //     }
    //   }
    // },
    dataLabels: {
      enabled: true,
      formatter: function (val: any) {
        return val + "%";
      },
      offsetY: -20,
      style: {
        fontSize: "12px",
        colors: ["#304758"]
      }
    },

    xaxis: {
      categories: [
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
      ],
      position: "top",
      labels: {
        offsetY: -18
      },
      axisBorder: {
        show: false
      },
      axisTicks: {
        show: false
      },
      crosshairs: {
        fill: {
          type: "gradient",
          gradient: {
            colorFrom: "#D8E3F0",
            colorTo: "#BED1E6",
            stops: [0, 100],
            opacityFrom: 4,
            opacityTo: 5
          }
        }
      },
      tooltip: {
        enabled: true,
        offsetY: -35
      }
    },
    // fill: {
    //   type: "gradient",
    //   gradient: {
    //     shade: "light",
    //     type: "horizontal",
    //     shadeIntensity: 0.25,
    //     gradientToColors: undefined,
    //     inverseColors: true,
    //     opacityFrom: 1,
    //     opacityTo: 1,
    //     stops: [50, 0, 100, 100]
    //   }
    // },
    yaxis: {
      axisBorder: {
        show: false
      },
      axisTicks: {
        show: false
      },
      labels: {
        show: false,
        formatter: function (val: any) {
          return val + "%";
        }
      }
    },
    title: {
      text: "Monthly Inflation in Argentina, 2002",
      floating: 0,
      offsetY: 320,
      align: "center",
      style: {
        color: "#444"
      }
    }
  };
  listOfImages: any[] = [];
  Exportloading: boolean = false;
  constructor(
    private trapService: TrapService,
    private _ActivatedRoute: ActivatedRoute,
    private _sharedService: SharedService
  ) { }

  ngOnInit() {
    this._ActivatedRoute.paramMap.subscribe((param: ParamMap) => {
      this.trapId = +param.get('id')!;
      this.GetCountOfMosuqitoesPerMonth();
      this.GetCountOfMosuqitoesToLast12Months();
      this.GetCountOfMosuqitoesPerSevenDaysMosuqitoes();
      this.GetCountOfMosuqitoesPerSevenDaysFly();
      this.GetStatisticsForAllTrapsReadingsAsInsects();
    })
  }
  // charts

  GetStatisticsForAllTrapsReadingsAsInsects() {
    this.trapService.GetStatisticsForTrapReadingsAsInsects(this.trapId).subscribe({
      next: (res: any) => {
        this.statisticsForAllTrapsReadingsAsInsects = res.data;
      }
    })
  }

  GetCountOfMosuqitoesPerMonth() {
    this.trapService.GetCountOfMosuqitoesToLastSixMonthsForTrap(this.trapId).subscribe({
      next: (res: any) => {
        this.mosuqitoesPerMonth = res.data
      }
    })
  }

  GetCountOfMosuqitoesToLast12Months() {
    this.trapService.GetCountOfMosuqitoesTo12MonthsForSpecificTrap(this.trapId).subscribe({
      next: (res: any) => {
        this.countOfMosuqitoesToLast12Months = res.data
      }
    })
  }

  GetCountOfMosuqitoesPerSevenDaysMosuqitoes() {
    this.trapService.GetCountOfMosuqitoesPerSevenDaysForSpecificTrap(this.trapId, true).subscribe({
      next: (res: any) => {
        this.countOfMosuqitoesPerSevenDaysMosuqitoes = res.data
      }
    })
  }

  GetCountOfMosuqitoesPerSevenDaysFly() {
    this.trapService.GetCountOfMosuqitoesPerSevenDaysForSpecificTrap(this.trapId, false).subscribe({
      next: (res: any) => {
        this.countOfMosuqitoesPerSevenDaysFly = res.data
      }
    })
  }

  async onImg1() {
    return new Promise((resolve, reject) => {
      html2canvas(document.getElementById(`chart1`)!, {
        useCORS: true,
        allowTaint: false,
      }).then((canvas) => {
        canvas.toBlob(async (blob: any) => {
          let file = await new File([blob], `1.png`, { type: "image/png" });
          let reader = new FileReader();
          reader.onload = () => {
            let base64Data = reader.result;
            resolve(base64Data);
          };
          reader.readAsDataURL(file);
        }, 'image/png');
      }).catch((error) => {
        reject(error);
      });
    });
  }

  async onImg2() {
    return new Promise((resolve, reject) => {
      html2canvas(document.getElementById(`chart2`)!, {
        useCORS: true,
        allowTaint: false,
      }).then((canvas) => {
        canvas.toBlob(async (blob: any) => {
          let file = await new File([blob], `2.png`, { type: "image/png" });
          let reader = new FileReader();
          reader.onload = () => {
            let base64Data = reader.result;
            resolve(base64Data);
          };
          reader.readAsDataURL(file);
        }, 'image/png');
      }).catch((error) => {
        reject(error);
      });
    });
  }

  async onImg3() {
    return new Promise((resolve, reject) => {
      html2canvas(document.getElementById(`chart3`)!, {
        useCORS: true,
        allowTaint: false,
      }).then((canvas) => {
        canvas.toBlob(async (blob: any) => {
          let file = await new File([blob], `3.png`, { type: "image/png" });
          let reader = new FileReader();
          reader.onload = () => {
            let base64Data = reader.result;
            resolve(base64Data);
          };
          reader.readAsDataURL(file);
        }, 'image/png');
      }).catch((error) => {
        reject(error);
      });
    });
  }

  async onImg4() {
    return new Promise((resolve, reject) => {
      html2canvas(document.getElementById(`chart4`)!, {
        useCORS: true,
        allowTaint: false,
      }).then((canvas) => {
        canvas.toBlob(async (blob: any) => {
          let file = await new File([blob], `4.png`, { type: "image/png" });
          let reader = new FileReader();
          reader.onload = () => {
            let base64Data = reader.result;
            resolve(base64Data);
          };
          reader.readAsDataURL(file);
        }, 'image/png');
      }).catch((error) => {
        reject(error);
      });
    });
  }

  async onImg5() {
    return new Promise((resolve, reject) => {
      html2canvas(document.getElementById(`chart5`)!, {
        useCORS: true,
        allowTaint: false,
      }).then((canvas) => {
        canvas.toBlob(async (blob: any) => {
          let file = await new File([blob], `5.png`, { type: "image/png" });
          let reader = new FileReader();
          reader.onload = () => {
            let base64Data = reader.result;
            resolve(base64Data);
          };
          reader.readAsDataURL(file);
        }, 'image/png');
      }).catch((error) => {
        reject(error);
      });
    });
  }

  async exportExcel() {
    this.Exportloading = true;
    const listOfCharts: any[] = [
      { img: await this.onImg1(), currentRow: 1, col: 8 , width:600},
      { img: await this.onImg2(), currentRow: 1, col: 18 , width:600},
      { img: await this.onImg3(), currentRow: 22, col: 8 , width:1240},
      { img: await this.onImg4(), currentRow: 44, col: 8 , width:600},
      { img: await this.onImg5(), currentRow: 44, col: 18 , width:600}
    ];

    const excel = new GenerateExcel();
    const workbook = new Workbook();

    const worksheet = workbook.addWorksheet('trap details', {
      // views: [{ state: 'frozen', xSplit: 4, ySplit: 9, rightToLeft: true }],
    });

    for (let index = 0; index < listOfCharts.length + 1; index++) {
      await excel.getBase64ImageFromUrl(listOfCharts[index]?.img).then((dataUrl: any) => {
        let img = new Image();
        img.src = dataUrl;
        img.onload = () => {
          let width = img.width;
          let chart = workbook.addImage({ base64: dataUrl, extension: 'png' });
          worksheet.addImage(chart, {
            tl: { col: listOfCharts[index]?.col, row: listOfCharts[index]?.currentRow },
            ext: { width: listOfCharts[index]?.width, height: 400 }
          });
        };
      });
    }

    workbook.xlsx.writeBuffer().then((data: any) => {
      const blob = new Blob([data], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });
      fileS.saveAs(blob, `Report Trap ${this.trapId}` + '.xlsx');
    });

    this.Exportloading = false;
  }
}
