import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ErrorInterface } from '@modules/error.interface';
import {
  CounterScheual,
  FanScheules,
  ValveScheual,
} from '@modules/interfaces/scheules-interface';
import { Trap } from '@modules/interfaces/trap-interface';
import { TrapService } from '@modules/services/trap.service';
import { SharedService } from '@modules/shared.service';
import { MessageService } from 'primeng/api';
import { EMPTY } from 'rxjs';
@Component({
  selector: 'app-managmentTrap',
  templateUrl: './managmentTrap.component.html',
  styleUrls: ['./managmentTrap.component.css'],
})
export class ManagmentTrapComponent implements OnInit {
  scheualFanList: FanScheules[] = [];
  scheualValveList: ValveScheual[] = [];
  scheualCounterList: CounterScheual[] = [];
  fanPerformance: number = 0;
  valveQutPerformance: number = 0;
  isCounterOn: boolean = true;
  myRole: any;
  isSchedule: boolean = true;
  isThereEmergency: boolean = false;
  isfileDate: boolean = false;
  isDone: boolean = false;
  fanArray: any[] = [
    { id: 0, scdTime: 0, status: false },
    { id: 1, scdTime: 1, status: false },
    { id: 2, scdTime: 2, status: false },
    { id: 3, scdTime: 3, status: false },
    { id: 4, scdTime: 4, status: false },
    { id: 5, scdTime: 5, status: false },
    { id: 6, scdTime: 6, status: false },
    { id: 7, scdTime: 7, status: false },
    { id: 8, scdTime: 8, status: false },
    { id: 9, scdTime: 9, status: false },
    { id: 10, scdTime: 10, status: false },
    { id: 11, scdTime: 11, status: false },
    { id: 12, scdTime: 12, status: false },
    { id: 13, scdTime: 13, status: false },
    { id: 14, scdTime: 14, status: false },
    { id: 15, scdTime: 15, status: false },
    { id: 16, scdTime: 16, status: false },
    { id: 17, scdTime: 17, status: false },
    { id: 18, scdTime: 18, status: false },
    { id: 19, scdTime: 19, status: false },
    { id: 20, scdTime: 20, status: false },
    { id: 21, scdTime: 21, status: false },
    { id: 22, scdTime: 22, status: false },
    { id: 23, scdTime: 23, status: false },
  ];
  valveQutArray: any[] = [
    { id: 0, scdTime: 0, status: false },
    { id: 1, scdTime: 1, status: false },
    { id: 2, scdTime: 2, status: false },
    { id: 3, scdTime: 3, status: false },
    { id: 4, scdTime: 4, status: false },
    { id: 5, scdTime: 5, status: false },
    { id: 6, scdTime: 6, status: false },
    { id: 7, scdTime: 7, status: false },
    { id: 8, scdTime: 8, status: false },
    { id: 9, scdTime: 9, status: false },
    { id: 10, scdTime: 10, status: false },
    { id: 11, scdTime: 11, status: false },
    { id: 12, scdTime: 12, status: false },
    { id: 13, scdTime: 13, status: false },
    { id: 14, scdTime: 14, status: false },
    { id: 15, scdTime: 15, status: false },
    { id: 16, scdTime: 16, status: false },
    { id: 17, scdTime: 17, status: false },
    { id: 18, scdTime: 18, status: false },
    { id: 19, scdTime: 19, status: false },
    { id: 20, scdTime: 20, status: false },
    { id: 21, scdTime: 21, status: false },
    { id: 22, scdTime: 22, status: false },
    { id: 23, scdTime: 23, status: false },
  ];
  counterArray: any[] = [
    { id: 0, scdTime: 0, status: false },
    { id: 1, scdTime: 1, status: false },
    { id: 2, scdTime: 2, status: false },
    { id: 3, scdTime: 3, status: false },
    { id: 4, scdTime: 4, status: false },
    { id: 5, scdTime: 5, status: false },
    { id: 6, scdTime: 6, status: false },
    { id: 7, scdTime: 7, status: false },
    { id: 8, scdTime: 8, status: false },
    { id: 9, scdTime: 9, status: false },
    { id: 10, scdTime: 10, status: false },
    { id: 11, scdTime: 11, status: false },
    { id: 12, scdTime: 12, status: false },
    { id: 13, scdTime: 13, status: false },
    { id: 14, scdTime: 14, status: false },
    { id: 15, scdTime: 15, status: false },
    { id: 16, scdTime: 16, status: false },
    { id: 17, scdTime: 17, status: false },
    { id: 18, scdTime: 18, status: false },
    { id: 19, scdTime: 19, status: false },
    { id: 20, scdTime: 20, status: false },
    { id: 21, scdTime: 21, status: false },
    { id: 22, scdTime: 22, status: false },
    { id: 23, scdTime: 23, status: false },
  ];
  newFanChart: any[] = [];
  newValveChart: any[] = [];
  newCounterChart: any[] = [];

  allTraps: Trap[] = [];
  trapDetails: Trap = {
    isThereEmergency: false,
    fileDate: '',
    isWorking: false,
    isDone: false,
    id: 0,
    name: '',
    serialNumber: '',
    iema: '',
    valveQut: '',
    fan: '',
    isCounterOn: false,
    isCounterReadingFromSimCard: false,
    isScheduleOn: false,
    readingDate: new Date(),
    lat: 0,
    long: 0,
    trapEmergencies: [],
    trapCounterSchedules: [],
    trapFanSchedules: [],
    trapValveQutSchedules: [],
    categoryId: 0,
    countryId: 0,
    stateId: 0,
  };

  // Check validation whith submit
  id: number = 0;
  submitted: boolean = false;
  // dialog data
  buttonClass: string = '';
  buttonTitle: string = '';
  // form Data
  // AddForm : FormGroup;
  schedulService: any;
  allCountries: any[] = [];
  allStates: any[] = [];
  allCategories: any[] = [];
  // get validation from form
  get addForm() {
    return this.trap_form.controls;
  }
  @Input() trapId: number = 0;
  @Output() onTrapCloseDialog: EventEmitter<boolean> = new EventEmitter();
  constructor(
    public sharedService: SharedService,
    private trapService: TrapService,
    private messageService: MessageService,
    private route: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder
    // private DatePipe:DatePipe
    // private formatDate:formatDate
  ) {
    this.myRole = localStorage.getItem('trap_role');
    this.GetAllCountries();
    this.GetAllCategories();
  }

  trap_form: FormGroup = this.fb.group({
    Name: new FormControl('', [Validators.required]),
    SerialNumber: new FormControl('', [Validators.required]),
    Iema: new FormControl('0'),
    Lat: new FormControl('0.0', [Validators.required]),
    Long: new FormControl('0.0', [Validators.required]),
    Fan: new FormControl(0, [Validators.required]),
    ValveQut: new FormControl(0, [Validators.required]),
    IsCounterOn: new FormControl(false, [Validators.required]),
    IsScheduleOn: new FormControl(false, [Validators.required]),
    IsThereEmergency: new FormControl(false, [Validators.required]),
    TrapFanSchedules: new FormControl([]),
    TrapValveQutSchedules: new FormControl([]),
    TrapCounterSchedules: new FormControl([]),
    fileDate: new FormControl(''),
    isCounterReadingFromSimCard: new FormControl(false),
    countryId: new FormControl(null , [Validators.required]),
    stateId: new FormControl(null),
    categoryId: new FormControl(null),
  });

  ngOnInit() {
    if (this.trapId) {
      this.getTrap(this.trapId);
    }
    this.trap_form.get('isCounterReadingFromSimCard')?.valueChanges.subscribe((val: any) => {
      if (val) {
        this.trap_form.get('fileDate')?.setValidators([Validators.required])
      } else {
        this.trap_form.get('fileDate')?.clearValidators();
        this.trap_form.get('fileDate')?.reset();
      }
      this.trap_form.get("fileDate")?.updateValueAndValidity();
    })
    // this.trap_form.get('fileDate')?.valueChanges.subscribe((res:any)=>{
    //   this.formateFileText(res)
    // })
  }
  formateDateFile(value: string) {
    return value.slice(0, 10)
  }

  getTrap(id: number) {
    this.trapService.GetTrap(id).subscribe(
      (res: any) => {
        this.trapDetails = res.data;
      },
      (error: ErrorInterface) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      },
      () => {
        if (this.trapDetails.trapCounterSchedules.length == 24) {
          this.counterArray = this.trapDetails.trapCounterSchedules;
        }
        if (this.trapDetails.trapFanSchedules.length == 24) {
          this.fanArray = this.trapDetails.trapFanSchedules;
        }
        if (this.trapDetails.trapValveQutSchedules.length == 24) {
          this.valveQutArray = this.trapDetails.trapValveQutSchedules;
        }
        this.fanPerformance = Number(this.trapDetails.fan);
        this.valveQutPerformance = Number(this.trapDetails.valveQut);
        this.isCounterOn = this.trapDetails.isCounterOn;
        this.isSchedule = this.trapDetails.isScheduleOn;
        this.isThereEmergency = this.trapDetails.isThereEmergency;
        // this.isfileDate = this.trapDetails.isDone;
        // this.isfileDate = this.trapDetails.isCounterReadingFromSimCard;
        this.GetAllStates(this.trapDetails.countryId);
        if (this.myRole !== 'SuperAdmin') {
          var str = this.trapDetails.serialNumber;
          var sliced = '**-***-****-' + str.slice(-6);
          this.trap_form.patchValue({
            Name: this.trapDetails.name,
            SerialNumber: sliced,
            Iema: this.trapDetails.iema,
            Lat: `${this.trapDetails.lat}`,
            Long: `${this.trapDetails.long}`,
            Fan: this.trapDetails.fan,
            ValveQut: this.trapDetails.valveQut,
            IsCounterOn: this.trapDetails.isCounterOn,
            IsScheduleOn: this.trapDetails.isScheduleOn,
            TrapFanSchedules: this.fanArray,
            TrapValveQutSchedules: this.valveQutArray,
            IsThereEmergency: this.isThereEmergency,
            TrapCounterSchedules: this.counterArray,
            categoryId: this.trapDetails.categoryId,
            countryId: this.trapDetails.countryId,
            stateId: this.trapDetails.stateId,
            isCounterReadingFromSimCard: this.trapDetails.isCounterReadingFromSimCard,
            // fileDate: this.trapDetails.fileDate ? this.formateDateFile(this.trapDetails.fileDate) : ''
          });
        }

        if (this.myRole == 'SuperAdmin') {
          var str = this.trapDetails.serialNumber;
          var sliced = str.slice(-6);
          this.trap_form.patchValue({
            Name: this.trapDetails.name,
            SerialNumber: this.trapDetails.serialNumber,
            Iema: this.trapDetails.iema,
            Lat: `${this.trapDetails.lat}`,
            Long: `${this.trapDetails.long}`,
            Fan: this.trapDetails.fan,
            ValveQut: this.trapDetails.valveQut,
            IsCounterOn: this.trapDetails.isCounterOn,
            IsScheduleOn: this.trapDetails.isScheduleOn,
            IsThereEmergency: this.isThereEmergency,
            TrapFanSchedules: this.fanArray,
            TrapValveQutSchedules: this.valveQutArray,
            TrapCounterSchedules: this.counterArray,
            isCounterReadingFromSimCard: this.trapDetails.isCounterReadingFromSimCard,
            categoryId: this.trapDetails.categoryId,
            countryId: this.trapDetails.countryId,
            stateId: this.trapDetails.stateId,
            // fileDate: this.trapDetails.fileDate ? this.formateDateFile(this.trapDetails.fileDate) : ''
          });
        }
        // this.trap_form.patchValue({
        //   Name: this.trapDetails.name,
        //   SerialNumber: this.trapDetails.serialNumber,
        //   Iema: this.trapDetails.iema,
        //   Lat: this.trapDetails.lat,
        //   Long: this.trapDetails.long,
        //   Fan: this.trapDetails.fan,
        //   ValveQut: this.trapDetails.valveQut,
        //   IsCounterOn: this.trapDetails.isCounterOn,
        //   IsScheduleOn: this.trapDetails.isScheduleOn,
        //   TrapFanSchedules: this.fanArray,
        //   TrapValveQutSchedules: this.valveQutArray,
        //   TrapCounterSchedules: this.counterArray,
        // });
      }
    );
  }

  addScheule() {
    this.newFanChart = [];
    this.newValveChart = [];
    this.newCounterChart = [];
    for (let i = 0; i < this.fanArray.length; i++) {
      this.newFanChart.push({
        scdTime: this.fanArray[i].scdTime,
        status: this.fanArray[i].status,
      });
    }

    for (let i = 0; i < this.valveQutArray.length; i++) {
      this.newValveChart.push({
        scdTime: this.valveQutArray[i].scdTime,
        status: this.valveQutArray[i].status,
      });
    }

    for (let i = 0; i < this.counterArray.length; i++) {
      this.newCounterChart.push({
        scdTime: this.counterArray[i].scdTime,
        status: this.counterArray[i].status,
      });
    }
  }
  
  formateFileText(date: any) {
    if (!date) {
      return
    }
    var datePipe = new DatePipe("en-US");
    let formatedateString = datePipe.transform(date, "yy-M-d");
    console.log(formatedateString);
    
    let formateDate = `${formatedateString}.TXT`;
    return formateDate
  }

  GetAllCountries() {
    this.trapService.GetAllCountries().subscribe({
      next: (res: any) => {
        this.allCountries = res.data
      },
      error: (error: any) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      }
    })
  }

  GetAllStates(id:number) {
    if(id){
      this.trapService.GetAllStates(id).subscribe({
        next: (res: any) => {
          this.allStates = res.data
        },
        error: (error: any) => {
          this.sharedService.handleError(error);
          this.messageService.add(this.sharedService.toastErrorHandler(error.message));
        }
      })
    }else{
      this.allStates = [];
    }
  }

  GetAllCategories() {
    this.trapService.GetAllCategories().subscribe({
      next: (res: any) => {
        this.allCategories = res.data
      },
      error: (error: any) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      }
    })
  }

  AddTrap() {
    this.submitted = true;
    this.addScheule();
    this.trap_form.patchValue({
      TrapFanSchedules: this.newFanChart,
      TrapValveQutSchedules: this.newValveChart,
      TrapCounterSchedules: this.newCounterChart,
      Fan: `${this.fanPerformance}`,
      ValveQut: `${this.valveQutPerformance}`,
      IsCounterOn: this.isCounterOn,
      IsScheduleOn: this.isSchedule,
      IsThereEmergency: this.isThereEmergency,
      // isCounterReadingFromSimCard: this.isfileDate,

      fileDate: this.trap_form.value.fileDate ? this.formateFileText(this.trap_form.value.fileDate) : ''
    });
    if (this.trap_form.valid && this.submitted) {
      if (this.trapId) {
        if (this.myRole !== 'SuperAdmin') {
          this.trap_form.patchValue({
            SerialNumber: this.trapDetails.serialNumber,
          });
        }
        ////////////
        console.log(this.trap_form.value);
        let value: any = this.trap_form.value;
        value['id'] = this.trapId;
        // value['fileDate'] = this.formateFileText(this.trap_form.value.fileDate);
        this.trapService.EditTrap(this.trapId, value).subscribe(
          () => { },
          (error: ErrorInterface) => {
            this.sharedService.handleError(error);
            error.errors.forEach((err) => {
              this.messageService.add(
                this.sharedService.toastErrorHandler(err)
              );
            });
          },
          () => {
            this.trap_form.reset();
            this.messageService.add(
              this.sharedService.toastSuccessRequest('Edited successfully')
            );
            this.onTrapCloseDialog.emit(true);
          }
        );
      } else {
        this.trapService.AddTrap(this.trap_form.value).subscribe(
          () => { },
          (error: ErrorInterface) => {
            this.sharedService.handleError(error);
            error.errors.forEach((err) => {
              this.messageService.add(
                this.sharedService.toastErrorHandler(err)
              );
            });
          },
          () => {
            // this.clearSave();
            this.trap_form.reset();
            this.messageService.add(
              this.sharedService.toastSuccessRequest('Trap added successfully')
            );

            for (let i = 0; i < this.fanArray.length; i++) {
              this.fanArray[i].status = false;
            }

            for (let i = 0; i < this.valveQutArray.length; i++) {
              this.valveQutArray[i].status = false;
            }

            for (let i = 0; i < this.counterArray.length; i++) {
              this.counterArray[i].status = false;
            }
            this.onTrapCloseDialog.emit(true);

          }
        );
      }
    }
  }
}
