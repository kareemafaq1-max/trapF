import { DatePipe } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ErrorInterface } from '@modules/error.interface';
import { GenerateExcel } from '@modules/GenerateExcel';
import {  Trap } from '@modules/interfaces/trap-interface';
import { TrapService } from '@modules/services/trap.service';
import { SharedService } from '@modules/shared.service';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-allTraps',
  templateUrl: './allTraps.component.html',
  styleUrls: ['./allTraps.component.css'],
})
export class AllTrapsComponent implements OnInit {
  allTraps: Trap[] = [];
  myRole: any;
  displayDelete: boolean = false;
  trapIdForDelete: number = 0;
  trapId: number = 0;
  trapName: string = '';
  trapNameForDelete: string = '';
  filterForm!: FormGroup;
  displayTrap:boolean = false;
  listOfTraps:any[] = [];
  listOfCategories:any[] = [];
  constructor(
    public sharedService: SharedService,
    private trapService: TrapService,
    private messageService: MessageService,
    private fb:FormBuilder
  ) {
    this.filterForm = this.fb.group({
      SerialNumber: null,
      TrapId: null,
      categoryId: null
    })
    this.myRole = localStorage.getItem('trap_role');
    this.GetAllCategories();
  }
  closeDialog( event :any){
    this.displayTrap = false;
    this.getAllTraps();
  }
  ngOnInit() {
    this.getAllTraps();
    this.ListOfTraps()
  }


  getAllTraps() {
    this.trapService.GetAllTraps(this.filterForm.value).subscribe(
      (res: any) => {
        this.allTraps = res.data;
      },
      (error: ErrorInterface) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      },
      () => {
      }
    );
  }

  ListOfTraps() {
    this.trapService.ListOfTraps().subscribe(
      (res: any) => {
        this.listOfTraps = res.data.data;
      },
      (error: ErrorInterface) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      },
      () => {
      }
    );
  }
  GetAllCategories() {
    this.trapService.GetAllCategories().subscribe({
      next: (res: any) => {
        this.listOfCategories = res.data
      },
      error: (error: any) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      }
    })
  }

  ViewDelete(id: number, name: string) {
    this.trapIdForDelete = id;
    this.trapNameForDelete = name;
    this.displayDelete = true;
  }
  ViewTrap(id: number, name: string) {
    this.trapId = id;
    this.trapName = name;
    this.displayTrap = true;
  }
  Delete() {
    this.trapService.DeleteTrap(this.trapIdForDelete).subscribe(
      (res) => {
      },
      (error: ErrorInterface) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      },
      () => {
        this.getAllTraps();
        this.displayDelete = false;
      }
    );
  }

  async exportExcel() {
    var datePipe = new DatePipe("en-US");

    const excel = new GenerateExcel();
    const workbook = new Workbook();
    const worksheet = workbook.addWorksheet('Sharing Data');

    // Add Row and formatting
    worksheet.addRow([]);

    const titleRow1 = worksheet.addRow([
      'Electronic Insect Monitoring Station',
    ]);
    excel.headStyle1(titleRow1);
    excel.mergeCell('A2:D3', worksheet);

    //Add Image
    await excel
      .getBase64ImageFromUrl('assets/img/logo.png')
      .then((dataUrl: any) => {
        let logo = workbook.addImage({ base64: dataUrl, extension: 'png' });
        worksheet.addImage(logo, 'J2:M6');
      });

    worksheet.addRow([]);

    // Add Row and formatting
    const titleRow = worksheet.addRow(['Users Report']);
    excel.headStyle2(titleRow);
    excel.mergeCell('A5:J6', worksheet);

    //Add Content
    worksheet.addRow([]);
    worksheet.addRow([]);

    // Add Header Row
    const headerRow = worksheet.addRow([
      'Seria Number',
      'Trap Name',
      // 'Date',
      // 'Time',
      // 'Small Mosuqitoes',
      // 'Large Mosuqitoes',
      // 'Mosuqitoes',
      // 'Other',
      'Status',
      'Fan',
      'valve Qut',
      'Latitude',
      'Longitude',
    ]);

    // Cell Style : Fill and Border
    excel.tableHeadStyle1(headerRow);

    // Add Data and Conditional Formatting
    this.allTraps.forEach((d: any) => {
      let row = worksheet.addRow([
        d.serialNumber,
        d.name,
        // datePipe.transform(d.readingDate, "yyyy-MM-dd"),
        // d.readingTime,
        // d.readingsmall,
        // d.readingLarg,
        // d.readingMosuqitoes,
        // d.readingFly,
        d.isCounterOn ? 'On' : 'Off',
        d.fan,
        d.valveQut,
        d.lat,
        d.long
      ]);
      row.alignment = { vertical: 'middle', horizontal: 'center' };
    });

    worksheet.columns.forEach((column, index) => {
      column.width = 15;
    });
    workbook.xlsx.writeBuffer().then((data: any) => {
      const blob = new Blob([data], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });
      fs.saveAs(blob, 'Trap Report_' + new Date().getDate() + '.xlsx');
    });
  }
}
