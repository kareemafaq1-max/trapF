import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CounterScheual } from '@modules/interfaces/scheules-interface';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  trapId: number = 0
  constructor( private route: ActivatedRoute ) {
    this.route.paramMap.forEach((params: any) => {
      this.trapId = params.get('id');
    });
  }

  ngOnInit() {
  }
  fanPerformance: number = 0;
  valveQutPerformance: number = 0;
  isCounter: boolean = false;

  fanChart1: any[] = [
    { id: 0, status: false },
    { id: 1, status: false },
    { id: 2, status: false },
    { id: 3, status: false },
    { id: 4, status: false },
    { id: 5, status: false },
    { id: 6, status: false },
    { id: 7, status: false },
    { id: 8, status: false },
    { id: 9, status: false },
    { id: 10, status: false },
    { id: 11, status: false },
    { id: 12, status: false },
    { id: 13, status: false },
    { id: 14, status: false },
    { id: 15, status: false },
    { id: 16, status: false },
    { id: 17, status: false },
    { id: 18, status: false },
    { id: 19, status: false },
    { id: 20, status: false },
    { id: 21, status: false },
    { id: 22, status: false },
    { id: 23, status: false },
  ];
  fanChart2: any[] = [
    { id: 0, status: false },
    { id: 1, status: false },
    { id: 2, status: false },
    { id: 3, status: false },
    { id: 4, status: false },
    { id: 5, status: false },
    { id: 6, status: false },
    { id: 7, status: false },
    { id: 8, status: false },
    { id: 9, status: false },
    { id: 10, status: false },
    { id: 11, status: false },
    { id: 12, status: false },
    { id: 13, status: false },
    { id: 14, status: false },
    { id: 15, status: false },
    { id: 16, status: false },
    { id: 17, status: false },
    { id: 18, status: false },
    { id: 19, status: false },
    { id: 20, status: false },
    { id: 21, status: false },
    { id: 22, status: false },
    { id: 23, status: false },
  ];

  fanChart3: any[] = [
    { id: 0, status: false },
    { id: 1, status: false },
    { id: 2, status: false },
    { id: 3, status: false },
    { id: 4, status: false },
    { id: 5, status: false },
    { id: 6, status: false },
    { id: 7, status: false },
    { id: 8, status: false },
    { id: 9, status: false },
    { id: 10, status: false },
    { id: 11, status: false },
    { id: 12, status: false },
    { id: 13, status: false },
    { id: 14, status: false },
    { id: 15, status: false },
    { id: 16, status: false },
    { id: 17, status: false },
    { id: 18, status: false },
    { id: 19, status: false },
    { id: 20, status: false },
    { id: 21, status: false },
    { id: 22, status: false },
    { id: 23, status: false },
  ];









  scheualCounterList: CounterScheual[] = []




















}
