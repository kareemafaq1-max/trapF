import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ErrorInterface } from '@modules/error.interface';
import { Trap } from '@modules/interfaces/trap-interface';
import { User } from '@modules/interfaces/users-interface';
import { TrapService } from '@modules/services/trap.service';
import { SharedService } from '@modules/shared.service';
import { UsersService } from '@modules/users.service';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-managementUser',
  templateUrl: './managementUser.component.html',
  styleUrls: ['./managementUser.component.css'],
})
export class ManagementUserComponent implements OnInit {
  // Check validation whith submit
  submitted: boolean = false;

  // form Data
  // AddForm: FormGroup;
  allTraps: Trap[] = [];
  userTraps = [];

  trapUserId = localStorage.getItem('userId');

  @Input() userId: string = '';
  @Input() isChangePasswordPage: boolean = false;
  @Output() reloadeUsers:EventEmitter<any> = new EventEmitter();
  userData: User = {
    id: '',
    email: '',
    name: '',
    roleId: '',
    roleName: '',
    trapIds: [],
  };

  add_form = new FormGroup({
    Username: new FormControl('', [Validators.required]),
    Password: new FormControl('', [
      Validators.required,
      Validators.minLength(8),
    ]),
    confirmPassword: new FormControl('', [
      Validators.required,
      Validators.minLength(8),
    ]),
    Email: new FormControl('', [Validators.required, Validators.email]),
    trapIds: new FormControl([], Validators.required),
  });

  change_password = new FormGroup({
    userId: new FormControl(''),
    // oldPassWord: new FormControl('', [Validators.required]),
    newPassWord: new FormControl('', [Validators.required]),
    confirmNewPassWord: new FormControl('', [Validators.required]),
  });


  constructor(
    public sharedService: SharedService,
    private fb: FormBuilder,
    private messageService: MessageService,
    private usersService: UsersService,
    private trapService: TrapService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    // this.route.params.subscribe((params) => {
    //   this.userId = params['id'];
    // });
    // if (this.router.url.startsWith('/users/editPasswordUser')) {
    //   this.isChangePasswordPage = true;
    // }
  }

  ngOnInit() {
    if (!this.isChangePasswordPage) {
      this.getAllTraps();
    }

    if (this.userId && !this.isChangePasswordPage) {
      this.getUser(this.userId);
    }
  }

  getUser(id: string) {
    this.usersService.GetUser(id).subscribe(
      (res: any) => {
        this.userData = res.data;
      },
      (error: ErrorInterface) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      },
      () => {
        this.add_form.controls['Username'].patchValue(this.userData.name);
        this.add_form.controls['Email'].patchValue(this.userData.email);
        this.add_form.controls['trapIds'].patchValue(this.userData.trapIds);
      }
    );
  }

  confirmedValidator(pass: any, conPass: any) {
    return (addForm: FormGroup) => {
      const password = addForm.controls[pass];
      const confPassword = addForm.controls[conPass];
      if (confPassword?.errors && !confPassword?.errors['confirmedValidator']) {
        return;
      }
      if (password?.value !== confPassword?.value) {
        confPassword.setErrors({ confirmedValidator: true });
      } else {
        confPassword?.setErrors(null);
      }
    };
  }


  getAllTraps() {
    this.trapService.GetAllTraps().subscribe(
      (res:any) => {
        this.allTraps = res.data;
      },
      (error: ErrorInterface) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      }
    );
  }

  addUser() {
    this.submitted = true;
    let value = this.add_form.value;
    value['id'] = this.userId
    if (this.userId) {
      this.usersService.UpdateUser(value).subscribe(
        (res) => {},
        (error: ErrorInterface) => {
          this.sharedService.handleError(error);
          error.errors.forEach((err) => {
            this.messageService.add(this.sharedService.toastErrorHandler(err));
          });
        },
        () => {
          this.submitted = false;
          this.router.navigateByUrl('/users');
          this.reloadeUsers.emit();
          this.add_form.reset();
          this.messageService.add(
            this.sharedService.toastSuccessRequest('Edited Successfully')
          );
        }
      );
    } else {
      this.usersService.AddUser(this.add_form.value).subscribe(
        (res) => {},
        (error: ErrorInterface) => {
          this.sharedService.handleError(error);
          error.errors.forEach((err) => {
            this.messageService.add(this.sharedService.toastErrorHandler(err));
          });
        },
        () => {
          this.submitted = false;
          this.add_form.reset();
          this.reloadeUsers.emit();
          this.messageService.add(
            this.sharedService.toastSuccessRequest('User added successfully')
          );
        }
      );
    }
  }

  changePassword() {
    this.submitted = true;

    // this.change_password.value.userId = this.userId
    this.change_password.controls['userId'].patchValue(this.userId);

    if (this.change_password.valid) {
      this.usersService.SetNewPasswordToSpecificUser(this.change_password.value).subscribe(
        (res) => {},
        (error: ErrorInterface) => {
          this.sharedService.handleError(error);
          error.errors.forEach((err) => {
            this.messageService.add(this.sharedService.toastErrorHandler(err));
          });
        },
        () => {
          this.submitted = false;
          this.reloadeUsers.emit();
          this.change_password.reset();
          this.messageService.add(
            this.sharedService.toastSuccessRequest(
              'Password Changed Successfully'
            )
          );
        }
      );
    }
  }
}
