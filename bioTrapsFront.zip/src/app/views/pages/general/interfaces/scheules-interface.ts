import { Trap } from "./trap-interface";

export interface FanScheules {
  id: number;
  scdTime: number;
  status: boolean;
  fanDegree: number;
  trapId: number;
  trap: Trap;
}

export interface CounterScheual {
  id: number;
  scdTime: number;
  status: boolean;
  isCounterOn: boolean;
  trapId: number;
  trap: Trap;
}

export interface ValveScheual {
  id: number;
  scdTime: number;
  status: boolean;
  valeDegree: number;
  trapId: number
  trap:Trap;
}




