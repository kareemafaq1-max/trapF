export interface TrapReads {
  id: number;
  readingDate: Date;
  readingTime: string;
  lat: number;
  long: number;
  counter: string;
  fan: string;
  co2: string;
  co2Val: string;
  readingsmall: string | undefined;
  readingLarg: string | undefined;
  readingMosuqitoes: string | undefined;
  readingTempIn: string;
  readingTempOut: string;
  readingWindSpeed: string;
  readingHumidty: string;
  ambLight: string;
  battery: string;
  reception: string;
  powerDraw: string;
  trapId: number;
  readingFly: string | undefined;
}

export interface TrapReadsList {
  data: Array<ReadData>;
  totalRecords: number;
}

export interface Trap {
  id: number;
  name: string;
  serialNumber: string;
  // status: number;
  isWorking: boolean;
  isDone: boolean;
  fileDate: string;
  iema: string;
  valveQut: string;
  fan: string;
  isCounterOn: boolean;
  isCounterReadingFromSimCard: boolean;
  isScheduleOn: boolean;
  isThereEmergency: boolean;
  readingDate: Date;
  lat: number;
  long: number;
  trapEmergencies: [];
  trapCounterSchedules: Array<Schedule>;
  trapFanSchedules: Array<Schedule>;
  trapValveQutSchedules: Array<Schedule>;
  //////////////////////////
  customReading?: string;
  customReadintTime?: string;
  lastLat?: number;
  lastLong?: number;
  categoryId?: number;
  countryId: number;
  stateId?: number;
}

export interface Schedule {
  id: number;
  scdTime: number;
  status: boolean;
}

export interface Read {
  data: Array<ReadData>;

}






export interface ReadAdmin {
  data: Array<ReadData>;
}

export interface Statistcs {
  numberOfUsers: number;
  numberOfWorking: number;
  numberOfNotWorking: number;
  numberOfTraps: number;
}







export interface ReadData {
  id: number;
  readingDate: string;
  readingTime: string;
  lat: number;
  long: number;
  counter: string;
  fan: string;
  co2: string;
  co2Val: string;
  readingsmall: string | undefined;
  readingLarg: string | undefined;
  readingMosuqitoes: string | undefined;
  readingTempIn: string;
  readingTempOut: string;
  readingWindSpeed: string;
  readingHumidty: string;
  ambLight: string;
  battery: string;
  reception: string;
  powerDraw: string;
  trapId: number;
  readingFly: string | undefined;

}

export interface GetTrapReadingsGroupedByDay {
  data: Array<Array<TrapReads>>;
  totalRecords: number;
}

// export interface LastTrapReadings {
//   data: Array<ReadData>;
//   numberOfUsers: 6;
//   numberOfWorking: 37;
//   numberOfNotWorking: 35;
//   numberOfTraps: 72;
// }
