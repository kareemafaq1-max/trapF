export interface AddUser {
  UserName: string;
  Email: string;
  Password: string;
  SelectedGroupId: number;
}

export interface User {
  id: string;
  email: string;
  name: string;
  roleId: string;
  roleName: string;
  trapIds:Array<number>;
}
