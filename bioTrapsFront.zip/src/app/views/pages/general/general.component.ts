import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { SharedService } from '@modules/shared.service';

@Component({
  selector: 'app-general',
  templateUrl: './general.component.html',
  styleUrls: ['./general.component.css']
})
export class GeneralComponent implements OnInit {

  constructor(public translate: TranslateService, private sharedService:SharedService) {
    // Load the translation
    translate.addLangs(['ar', 'en']);
    translate.setDefaultLang('en');
    let defLang: string = localStorage.getItem('lang') ?? 'en';
    translate.use(defLang.toLowerCase());
    sharedService.pageDir = defLang == 'en' ? true : false;

  }

  ngOnInit() {
  }

}
