import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment as env } from '@env/environment';
import { Observable } from 'rxjs';
import { AddUser, User } from '@modules/users-interface';
@Injectable({
  providedIn: 'root',
})
export class UsersService {
  baseURL: string = env.apiPath + 'Auth/';

  constructor(private http: HttpClient) {}

  AddUser(userData: AddUser) {
    return this.http.post(this.baseURL + 'CreateUser', userData);
  }

  ChangePassword(data: any) {
    return this.http.put(this.baseURL + 'ChangePassword', data);
  }

  SetNewPasswordToSpecificUser(data: any) {
    return this.http.put(this.baseURL + 'SetNewPasswordToSpecificUser', data);
  }
  
  GetUser(id: any) {
    return this.http.get(this.baseURL + 'GetUserById/' + id);
  }

  GetAllUsers(query:any): Observable<User> {
    const value:any = {};
    for (const key in query) {
      if (query[key]) {
        value[key] = query[key];
      }
    }
    return this.http.get<User>(this.baseURL + 'GetAllUsers' , {params:value});
  }

  DeleteUser(id: string) {
    return this.http.delete(this.baseURL + 'DeleteUser/' + id);
  }
  
  UpdateUser(data: any) {
    return this.http.put(this.baseURL + 'UpdateUser/' + data.id, data);
  }
}
