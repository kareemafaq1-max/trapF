import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment as env } from '@env/environment';
import { Observable } from 'rxjs';

import {
  Trap,
  TrapReadsList,
  Read,
  GetTrapReadingsGroupedByDay,
  Statistcs,
} from '@modules/trap-interface';
import { FormGroup } from '@angular/forms';

@Injectable({
  providedIn: 'root',
})
export class TrapService {
  baseURL: string = env.apiPath + 'Traps/';

  fakeLong: number = 0;
  fakeLat: number = 0;

  constructor(private http: HttpClient) { }

  GetTrapEmergencies(query: any={}): Observable<any> {
    const value: any = {};
    for (const key in query) {
      if (query[key]) {
        value[key] = query[key];
      }
    }
    return this.http.get<any>(env.apiPath + `TrapEmergencies/GetAllTrapEmergencies/${value.serialNumber}` , { params: value });
  }

  GetTrap(id: number): Observable<Trap> {
    return this.http.get<Trap>(this.baseURL + 'GetTrapById/' + id);
  }

  ListOfTraps(): Observable<Trap> {
    return this.http.get<Trap>(this.baseURL + 'ListOfTraps');
  }

  GetAllTraps(query: any = {}): Observable<Trap[]> {
    const value: any = {};
    for (const key in query) {
      if (query[key]) {
        value[key] = query[key];
      }
    }
    return this.http.get<Trap[]>(this.baseURL + 'GetAllTraps', { params: value });
  }
  GetLastReadingForAllTraps(query?:any): Observable<any> {
    const value: any = {};
    for (const key in query) {
      if (query[key]) {
        value[key] = query[key];
      }
    }
    return this.http.get<any>(env.apiPath + 'TrapReadings/GetLastReadingForAllTraps' , {params:value});
  }
  GetNumberOfTrapsOnly(): Observable<Statistcs> {
    return this.http.get<Statistcs>(env.apiPath + 'TrapReadings/GetStatisticsOfTrapsOnlyCurrentUser');
  }

  GetStatisticsForAllTrapsReadingsAsInsects(cateory:any = {}): Observable<Statistcs> {
    return this.http.get<Statistcs>(env.apiPath + 'TrapReadings/GetStatisticsForAllTrapsReadingsAsInsects' , {params:cateory});
  }

  GetCountOfMosuqitoesInDayOfMonthOfYear(query:any): Observable<Statistcs> {
    const value: any = {};
    for (const key in query) {
      if (query[key]) {
        value[key] = query[key];
      }
    }

    return this.http.post<Statistcs>(env.apiPath + 'TrapReadings/GetCountOfMosuqitoesInDayOfMonthOfYear' , value) ;
  }

  GetStatisticsForTrapReadingsAsInsects(trapId: number): Observable<any> {
    return this.http.get<any>(env.apiPath + `TrapReadings/GetStatisticsForTrapReadingsAsInsects/${trapId}`);
  }

  GetLastReadForTraps(): Observable<Read> {
    return this.http.get<Read>(env.apiPath + 'TrapReadings/GetLastReadingToCurrentUserTraps');
  }

  GetAllTrapReadings(Search: any): Observable<TrapReadsList> {
    return this.http.get<TrapReadsList>(
      env.apiPath + 'TrapReadings/GetAllTrapReadings',
      { params: { ...Search } }
    );
  }

  GetLastReadingToSpecifiedTrap(id: any): Observable<Read> {
    return this.http.get<Read>(env.apiPath + 'TrapReadings/GetLastReadingToSpecifiedTrap/' + id);
  }

  GetLastReadingToSpecifiedAllEmptyValueILatAndLongTrap(id: any): Observable<Read> {
    return this.http.get<Read>(env.apiPath + 'TrapReadings/GetLastReadingToSpecifiedAllEmptyValueILatAndLongTrap/' + id);
  }
  
  DeleteTrap(id: number) {
    return this.http.delete(this.baseURL + 'DeleteTrap/' + id);
  }

  AddTrap(trapData: Trap) {
    return this.http.post(this.baseURL + 'CreatTrap', trapData);
  }

  EditTrap(id: number, trapData: Trap) {
    return this.http.put(this.baseURL + 'UpdateTrap/' + id, trapData);
  }

  GetAllTrapReadingsPerDay(query: any): Observable<GetTrapReadingsGroupedByDay> {
    return this.http.get<GetTrapReadingsGroupedByDay>(
      env.apiPath + 'TrapReadings/GetAllTrapReadingsPerDay',
      {
        params: query
      }
    );
  }




  // charts
  GetCountOfMosuqitoesPerMonth() {
    return this.http.get(env.apiPath + 'TrapReadings/GetCountOfMosuqitoesPerMonth');
  }

  GetCountOfMosuqitoesToLast12Months() {
    return this.http.get(env.apiPath + 'TrapReadings/GetCountOfMosuqitoesToLast12Months');
  }
  
  GetCountOfMosuqitoesPerSevenDays(InsectType: boolean) {
    return this.http.get(env.apiPath + `TrapReadings/GetCountOfMosuqitoesPerSevenDays?isMosuqitoe=${InsectType}`);
  }

  GetAllCountries() {
    return this.http.get(env.apiPath + `Lookups/GetAllCountries`);
  }

  GetAllStates(id:number) {
    return this.http.get(env.apiPath + `Lookups/GetAllStates/${id}`);
  }

  GetAllCategories() {
    return this.http.get(env.apiPath + `Lookups/GetAllCategories`);
  }

  TrapFilterByCategory(id:number) {
    return this.http.get(env.apiPath + `Traps/TrapFilterByCategory/${id}`);
  }

  CreateCategory(form:any){
    return this.http.post(env.apiPath + `Lookups/CreateCategory` , form);
  }

  UpdateCategory(form:any){
    return this.http.put(env.apiPath + `Lookups/UpdateCategory/${form.id}` , form);
  }

  DeleteCategory(id:number){
    return this.http.delete(env.apiPath + `Lookups/DeleteCategory/${id}`);
  }


  // GetStatisticsForTrapReadingsAsInsects(trapId:number) {
  //   return this.http.get(env.apiPath + `TrapReadings/GetStatisticsForTrapReadingsAsInsects/${trapId}`);
  // }

  GetCountOfMosuqitoesToLastSixMonthsForTrap(trapId:number) {
    return this.http.get(env.apiPath + `TrapReadings/GetCountOfMosuqitoesToLastSixMonthsForTrap/${trapId}`);
  }

  GetCountOfMosuqitoesTo12MonthsForSpecificTrap(trapId:number) {
    return this.http.get(env.apiPath + `TrapReadings/GetCountOfMosuqitoesTo12MonthsForSpecificTrap/${trapId}`);
  }
  
  GetCountOfMosuqitoesPerSevenDaysForSpecificTrap( trapId:number , InsectType:boolean) {
    return this.http.get(env.apiPath + `TrapReadings/GetCountOfMosuqitoesPerSevenDaysForSpecificTrap/${trapId}?isMosuqitoe=${InsectType}`);
  }

  LoadData2Logs( body:any) {
    return this.http.post(env.apiPath + `Traps/LoadData2Logs` , {},{params:body});
  }
}
