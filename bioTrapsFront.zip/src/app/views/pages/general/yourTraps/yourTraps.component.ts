import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, RouterStateSnapshot } from '@angular/router';
import { SharedService } from '@modules/shared.service';
import { ErrorInterface } from '@modules/error.interface';
import { MessageService } from 'primeng/api';
import { ReadData, Trap } from '@modules/trap-interface';
import { TrapService } from '@modules/trap.service';
import { GenerateExcel } from '@modules/GenerateExcel';
import { DatePipe } from '@angular/common';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';

@Component({
  selector: 'app-yourTraps',
  templateUrl: './yourTraps.component.html',
  styleUrls: ['./yourTraps.component.css']
})
export class YourTrapsComponent implements OnInit {
  allTraps: Trap[] = []
  // allTrapsByCategory: Trap[] = []
  loading: boolean = true;
  active: string = 'card';
  noData: string = ''
  categoryId: number = 0;
  myRole: string = '';
  statisticsForAllTrapsReadingsAsInsects: any[] = [];
  displayTrap: boolean = false;
  trapId: number = 0;
  trapName: string = '';
  displayDelete: boolean = false;
  trapIdForDelete: number = 0;
  trapNameForDelete: string = '';
  lastReadingForAllTraps: any[] = [];
  userId:string = '';
  constructor(
    private trapService: TrapService,
    public sharedService: SharedService,
    private messageService: MessageService,
    private _activatedRoute: ActivatedRoute,
  ) { }

  ngOnInit() {
    this.myRole = localStorage.getItem('trap_role')!;
    this._activatedRoute.queryParamMap.subscribe((query:ParamMap)=>{
      this.userId = query.get('userId')!;
      this.categoryId = +query.get('categoryId')!;
      this.getAllTraps();
      this.GetLastReadingForAllTraps()
    })
    this._activatedRoute.paramMap.subscribe((param: any) => {
      // this.categoryId ? this.TrapFilterByCategory(this.categoryId) : null;
    })
  }

  refreshData() {
    this.GetLastReadingForAllTraps();
  }
  getAllTraps() {
    this.loading = true;
    const query = {
      categoryId: this.categoryId ,
      UserId:this.userId
    }
    this.trapService.GetAllTraps(query).subscribe(
      (res: any) => {
        this.allTraps = res.data;
        this.loading = false;
      },
      (error: ErrorInterface) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
        this.loading = false;
      },
      () => { }
    );
  }

  // TrapFilterByCategory(id: number) {
  //   this.loading = true;
  //   this.trapService.TrapFilterByCategory(id).subscribe({
  //     next: (res: any) => {
  //       this.allTrapsByCategory = res.data
  //       this.loading = false;
  //     },
  //     error: (error: any) => {
  //       this.sharedService.handleError(error);
  //       this.messageService.add(this.sharedService.toastErrorHandler(error.message));
  //       this.loading = false;
  //     }
  //   })
  // }

  ViewDelete(id: number, name: string) {
    this.trapIdForDelete = id;
    this.trapNameForDelete = name;
    this.displayDelete = true;
  }
  ViewTrap(id: number, name: string) {
    this.trapId = id;
    this.trapName = name;
    this.displayTrap = true;
  }
  Delete() {
    this.trapService.DeleteTrap(this.trapIdForDelete).subscribe(
      (res) => {
      },
      (error: ErrorInterface) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      },
      () => {
        this.getAllTraps();
        this.displayDelete = false;
      }
    );
  }
  closeDialog(event: any) {
    this.displayTrap = false;
    this.getAllTraps();
  }

  GetLastReadingForAllTraps() {
    this.trapService.GetLastReadingForAllTraps({ categoryId: this.categoryId , UserId:this.userId}).subscribe(
      (res: any) => {
        this.lastReadingForAllTraps = res.data.sort((a:any, b:any) => {
          // Compare readingDate
          if (a.readingDate > b.readingDate) return -1;
          if (a.readingDate < b.readingDate) return 1;
      
          // If readingDate is the same, compare readingTime
          const timeA = a.readingTime.split(':').map(Number);
          const timeB = b.readingTime.split(':').map(Number);
          if (timeA[0] > timeB[0]) return -1;
          if (timeA[0] < timeB[0]) return 1;
          if (timeA[1] > timeB[1]) return -1;
          if (timeA[1] < timeB[1]) return 1;
          return 0;
      });
      },
      (error: ErrorInterface) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      },
      () => { }
    );
  }

  async exportExcel() {
    var datePipe = new DatePipe("en-US");

    const excel = new GenerateExcel();
    const workbook = new Workbook();
    const worksheet = workbook.addWorksheet('Sharing Data');

    // Add Row and formatting
    worksheet.addRow([]);

    const titleRow1 = worksheet.addRow([
      'Electronic Insect Monitoring Station',
    ]);
    excel.headStyle1(titleRow1);
    excel.mergeCell('A2:D3', worksheet);

    //Add Image
    await excel
      .getBase64ImageFromUrl('assets/img/logo.png')
      .then((dataUrl: any) => {
        let logo = workbook.addImage({ base64: dataUrl, extension: 'png' });
        worksheet.addImage(logo, 'J2:M6');
      });

    worksheet.addRow([]);

    // Add Row and formatting
    const titleRow = worksheet.addRow(['Users Report']);
    excel.headStyle2(titleRow);
    excel.mergeCell('A5:J6', worksheet);

    //Add Content
    worksheet.addRow([]);
    worksheet.addRow([]);

    // Add Header Row
    const headerRow = worksheet.addRow([
      'Seria Number',
      'Trap Name',
      // 'Date',
      // 'Time',
      // 'Small Mosuqitoes',
      // 'Large Mosuqitoes',
      // 'Mosuqitoes',
      // 'Other',
      'Status',
      'Fan',
      'valve Qut',
      'Latitude',
      'Longitude',
    ]);

    // Cell Style : Fill and Border
    excel.tableHeadStyle1(headerRow);

    // Add Data and Conditional Formatting
    this.allTraps.forEach((d: any) => {
      let row = worksheet.addRow([
        d.serialNumber,
        d.name,
        // datePipe.transform(d.readingDate, "yyyy-MM-dd"),
        // d.readingTime,
        // d.readingsmall,
        // d.readingLarg,
        // d.readingMosuqitoes,
        // d.readingFly,
        d.isCounterOn ? 'On' : 'Off',
        d.fan,
        d.valveQut,
        d.lat,
        d.long
      ]);
      row.alignment = { vertical: 'middle', horizontal: 'center' };
    });

    worksheet.columns.forEach((column, index) => {
      column.width = 15;
    });
    workbook.xlsx.writeBuffer().then((data: any) => {
      const blob = new Blob([data], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });
      fs.saveAs(blob, 'Trap Report_' + new Date().getDate() + '.xlsx');
    });
  }
}
