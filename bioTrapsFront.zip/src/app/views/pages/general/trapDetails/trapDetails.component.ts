import { DatePipe, Location } from '@angular/common';
import {
  AfterViewInit,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  QueryList,
} from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import {
  chartOptions,
  ChartOptions,
} from '@modules/chartline/chartline.component';
import { ErrorInterface } from '@modules/error.interface';
import { GenerateExcel } from '@modules/GenerateExcel';
import { ReportService } from '@modules/report.service';
import { SharedService } from '@modules/shared.service';
import {
  GetTrapReadingsGroupedByDay,
  Read,
  ReadData,
  Trap,
  TrapReads,
  TrapReadsList,
} from '@modules/trap-interface';
import { TrapService } from '@modules/trap.service';
import { TranslateService } from '@ngx-translate/core';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';
import jsPDF from 'jspdf';
import { MessageService } from 'primeng/api';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-trapDetails',
  templateUrl: './trapDetails.component.html',
  styleUrls: ['./trapDetails.component.css'],
})
export class TrapDetailsComponent implements OnInit, OnDestroy {
  displayTrap: boolean = false;
  chartOptions1 = {
    plugins: {
      tooltips: {
        mode: 'index',
        intersect: false,
      },
      legend: {
        labels: false,
      },
    },
    scales: {
      x: {
        stacked: true,
        ticks: {
          color: '#f000',
        },
        grid: {
          color: '#ebedef',
        },
      },
      y: {
        stacked: true,
        ticks: {
          color: '#f000',
        },
        grid: {
          color: '#ebedef',
        },
      },
    },
  };
  myRole: any;
  chartOptions2 = {
    plugins: {
      tooltips: {
        mode: 'index',
        intersect: false,
      },
      legend: {
        labels: {
          color: '#495057',
        },
      },
    },
    scales: {
      x: {
        stacked: true,
        ticks: {
          color: '#495057',
        },
        grid: {
          color: '#ebedef',
        },
      },
      y: {
        stacked: false,
        ticks: {
          color: '#495057',
        },
        grid: {
          color: '#ebedef',
        },
      },
    },
  };
  labelsTime: any[] = [
    '00:00',
    '00:30',
    '01:00',
    '00:30',
    '02:00',
    '00:30',
    '03:00',
    '00:30',
    '04:00',
    '00:30',
    '05:00',
    '00:30',
    '06:00',
    '00:30',
    '07:00',
    '00:30',
    '08:00',
    '00:30',
    '09:00',
    '00:30',
    '10:00',
    '00:30',
    '11:00',
    '00:30',
    '12:00',
    '00:30',
    '13:00',
    '00:30',
    '14:00',
    '00:30',
    '15:00',
    '00:30',
    '16:00',
    '00:30',
    '17:00',
    '00:30',
    '18:00',
    '00:30',
    '19:00',
    '00:30',
    '20:00',
    '00:30',
    '21:00',
    '00:30',
    '22:00',
    '00:30',
    '23:00',
    '00:30',
  ];
  times: any[] = [
    '00:00',
    '00:15',
    '00:30',
    '00:45',
    '01:00',
    '01:15',
    '01:30',
    '01:45',
    '02:00',
    '02:15',
    '02:30',
    '02:45',
    '03:00',
    '03:15',
    '03:30',
    '03:45',
    '04:00',
    '04:15',
    '04:30',
    '04:45',
    '05:00',
    '05:15',
    '05:30',
    '05:45',
    '06:00',
    '06:15',
    '06:30',
    '06:45',
    '07:00',
    '07:15',
    '07:30',
    '07:45',
    '08:00',
    '08:15',
    '08:30',
    '08:45',
    '09:00',
    '09:15',
    '09:30',
    '09:45',
    '10:00',
    '10:15',
    '10:30',
    '10:45',
    '11:00',
    '11:15',
    '11:30',
    '11:45',
    '12:00',
    '12:15',
    '12:30',
    '12:45',
    '13:00',
    '13:15',
    '13:30',
    '13:45',
    '14:00',
    '14:15',
    '14:30',
    '14:45',
    '15:00',
    '15:15',
    '15:30',
    '15:45',
    '16:00',
    '16:15',
    '16:30',
    '16:45',
    '17:00',
    '17:15',
    '17:30',
    '17:45',
    '18:00',
    '18:15',
    '18:30',
    '18:45',
    '19:00',
    '19:15',
    '19:30',
    '19:45',
    '20:00',
    '20:15',
    '20:30',
    '20:45',
    '21:00',
    '21:15',
    '21:30',
    '21:45',
    '22:00',
    '22:15',
    '22:30',
    '22:45',
    '23:00',
    '23:15',
    '23:30',
    '23:45',
  ];
  data = {
    labels: this.labelsTime,
    datasets: [
      {
        type: 'line',
        label: '',
        borderColor: '#fd7e14',
        borderWidth: 2,
        fill: false,
        data: [0],
      },
      {
        type: 'line',
        label: '',
        borderColor: '#f00',
        borderWidth: 2,
        fill: false,
        data: [0],
      },
      {
        type: 'line',
        label: '',
        borderColor: '#0f0',
        borderWidth: 2,
        fill: false,
        data: [0],
      },
    ],
  };

  // fullData = {
  //   labels: [
  //     'January',
  //     'February',
  //     'March',
  //     'April',
  //     'May',
  //     'June',
  //     'July',
  //     'January',
  //     'February',
  //     'March',
  //     'April',
  //     'May',
  //     'June',
  //     'July',
  //     'January',
  //     'February',
  //     'March',
  //     'April',
  //     'May',
  //     'June',
  //     'July',
  //     'January',
  //     'February',
  //     'March',
  //     'April',
  //     'May',
  //     'June',
  //     'July',
  //   ],
  //   datasets: [
  //     {
  //       type: 'line',

  //       label: ' ',
  //       borderColor: '#fd7e14',
  //       borderWidth: 2,
  //       fill: false,
  //       data: [0],
  //     },
  //     {
  //       type: 'line',
  //       label: ' ',
  //       borderColor: '#f00',
  //       borderWidth: 2,
  //       fill: false,
  //       data: [0],
  //     },
  //     {
  //       type: 'line',
  //       label: ' ',
  //       borderColor: '#0f0',
  //       borderWidth: 2,
  //       fill: false,
  //       data: [0],
  //     },
  //     {
  //       type: 'bar',
  //       label: 'Counter',
  //       backgroundColor: '#ff990080',
  //       data: [0],
  //       borderColor: 'white',
  //     },
  //     {
  //       type: 'bar',
  //       label: 'Valve Qut',
  //       backgroundColor: '#0d6efd0',
  //       data: [0],
  //     },
  //     {
  //       type: 'bar',
  //       label: 'Fan',
  //       backgroundColor: '#41954460',
  //       data: [0],
  //     },
  //   ],
  // };

  dataDays = {
    labels: [0],

    datasets: [
      {
        type: 'line',
        label: '',

        borderColor: '#307bb2',
        borderWidth: 2,
        fill: false,
        data: [0],
      },
      {
        type: 'line',
        label: '',

        borderColor: 'rgb(255, 69, 96)',
        borderWidth: 2,
        fill: false,
        data: [0],
      },
      {
        type: 'line',
        label: '',

        borderColor: '#54aa54',
        borderWidth: 2,
        fill: false,
        data: [0],
      },
      {
        type: 'line',
        label: '',
        borderColor: '#ffc107',
        borderWidth: 2,
        fill: false,
        data: [0],
      },
    ],
  };
  costumLat: number = 0;
  costumLong: number = 0;

  viewChart: boolean = false;
  isAdmin: boolean = false;

  chartdaily: any[] = [];
  chartOptions: Partial<ChartOptions> = {};
  MapData: Subject<Read> = new Subject<Read>();
  chartToday: Subject<any[]> = new Subject<any[]>();
  chartWeek: Subject<any[]> = new Subject<any[]>();
  // Search Data
  Search: {
    TrapId: Number;
    chart: Boolean;
    list: Boolean;
    EndDate: String;
    StartDate: String;
    PageNumber: Number;
    PageSize: Number;
  };
  defaultSearchValues: boolean = true;
  loadingExcel: boolean = false;
  // Date start and end
  minDate = new Date('2023/02/01');
  startDate!: Date;
  endDate!: Date;
  trapReading: TrapReads[] = [];
  trapReads: TrapReadsList = { totalRecords: 0, data: [] };
  trapReadsPeriod: TrapReadsList = { totalRecords: 0, data: [] };
  trapCount: number = 0;
  nextRec: boolean = false;
  trapDetails: Trap = {
    fileDate: '',
    isDone: false,
    id: 0,
    name: '',
    serialNumber: '',
    iema: '',
    valveQut: '',
    fan: '',
    isWorking: false,
    isCounterOn: false,
    isCounterReadingFromSimCard: false,
    isScheduleOn: false,
    isThereEmergency: false,
    readingDate: new Date(),
    lat: 0,
    long: 0,
    trapEmergencies: [],
    trapCounterSchedules: [],
    trapFanSchedules: [],
    trapValveQutSchedules: [],
    countryId: 0
  };
  readingDate!: Date;
  readingTime!: Date;
  query: any = {};
  chartsData: any;
  trapDayReads: ReadData[] = [];
  trapReadsPeriodTable: ReadData[] = [];
  trapId: number = 0;
  LastReadForTrap: any = {
    fan: 0,
    valveQut: 0
  };
  SearchChartArrays: any[] = [];
  //last read for trap
  // lastReadTrap!: Read;
  // paginators
  totalRecords: number = 0;
  // Dialog
  displayDialog: boolean = false;
  submitted: boolean = false;

  Exportloading: boolean = false;

  dateNow: Date = new Date();
  // Start Data For Charts
  SearchChartData: any = { data: [], totalRecords: 0 };
  fanList = [];
  // EndData For Charts
  audio = new Audio();

  export = true;
  loadingTrap: boolean = false;
  currentHour = this.dateNow.getHours();
  currentMinutes = this.dateNow.getMinutes();
  currentYear = this.dateNow.getFullYear();
  currentMonth = (this.dateNow.getMonth() + 1).toString().padStart(2, '0');
  currentDay = this.dateNow.getDate().toString().padStart(2, '0');

  currentDate = `${this.currentYear}-${this.currentMonth}-${this.currentDay}`;
  currentTime = `${this.currentHour}-${this.currentMinutes}`;
  constructor(
    public translate: TranslateService,
    public location: Location,
    public sharedService: SharedService,
    private fb: FormBuilder,
    private trapService: TrapService,
    private ActivatedRoute: ActivatedRoute,
    private messageService: MessageService,
    private reportService: ReportService,
    private router: Router
  ) {
    this.ActivatedRoute.paramMap.subscribe((res: any) => {
      this.trapId = +res.get('id')
    })
    this.myRole = localStorage.getItem('trap_role')
    this.chartOptions = { ...chartOptions };
    this.query = {
      TrapId: 0,
      chart: false,
      list: false,
      // EndDate: '',
      // StartDate: '',
      PageNumber: 1,
      PageSize: 10,
    };
    this.Search = {
      TrapId: 0,
      chart: false,
      list: false,
      EndDate: '',
      StartDate: '',
      PageNumber: 1,
      PageSize: 10,
    };
  }

  ngOnInit() {
    if (localStorage.getItem('trap_role') == 'SuperAdmin') {
      this.isAdmin = true;
    }

    this.getTrap();
    this.getTodayRead();
    this.GetLastReadingToSpecifiedAllEmptyValueILatAndLongTrap();
    // this.getLastWeek();
    this.SearchLastDay(this.dateNow);
  }
  refreshData() {
    this.ngOnInit();
  }
  convertTime(value: string) {
    const [hours, minutes] = value.split(':');
    const formattedHours = `${Number(hours)}`;
    const formattedTime = `${formattedHours}:${minutes}`;
    return formattedTime;
  }
  delay() {
    setTimeout(() => {
      this.getTrapReport();
    }, 100);
  }

  async getTrapReport() {
    let formData = new FormData();

    await this.sharedService.htmlToCanvasWithAppendFormData(
      'trapDetails',
      formData
    );
    await this.sharedService.htmlToCanvasWithAppendFormData(
      'homeMap1',
      formData
    );
    await this.sharedService.htmlToCanvasWithAppendFormData(
      'trapMap2',
      formData
    );

    for (let i = 0; i < this.SearchChartArrays.length; i++) {
      await this.sharedService.htmlToCanvasWithAppendFormData(
        'trapDetailstitle' + i,
        formData
      );
    }

    // let list = document.querySelectorAll('.test');
    // for (let i = 0; i < list.length; i++) {
    //   await this.sharedService.htmlToCanvasWithAppendFormData(
    //     'maps' + i,
    //     formData
    //   );
    // }

    for (let i = 0; i < this.SearchChartArrays.length; i++) {
      await this.sharedService.htmlToCanvasWithAppendFormData(
        'trapDetailstitle' + i,
        formData
      );
    }

    this.reportService
      .GetTrapReport(this.trapId, formData)
      .subscribe((data) => {
        let blob = new Blob([data], { type: 'application/msword' });
        var downloadURL = window.URL.createObjectURL(blob);
        var link = document.createElement('a');
        link.href = downloadURL;
        link.download = `تقرير المصيدة.doc`;
        link.click();
        this.export = true;
      });
  }

  playAudio() {
    this.audio.src = "./assets/audio/emergency-alarm.mp3";
    this.audio.load();
    this.audio.setAttribute("autoplay", "")
  }

  pauseAudio() {
    this.audio.pause();
  }

  getTrap() {
    this.loadingTrap = true;
    this.trapService.GetTrap(this.trapId).subscribe(
      (res: any) => {
        this.loadingTrap = false;
        this.trapDetails = res.data;
        if (this.trapDetails.isThereEmergency) {
          this.playAudio();
        }
      },
      (error: ErrorInterface) => {
        // this.loadingTrap = false;
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      },
      () => {
        this.sharedService.trapTitle = 'BIOTRAPS : ' + this.trapDetails.name;
      }
    );
  }

  // function to handle date formate before send as a param
  onPageChange(event: any) {
    this.query.PageNumber = event.page + 1
    this.query.PageSize = event.rows
    this.SearchLastDay(this.query);
  }
  onPageChangeList(event: any) {
    this.Search.PageNumber = event.page + 1
    this.Search.PageSize = event.rows
    this.SearchFan(this.Search);
  }

  viewDialog() {
    this.displayDialog = true;
  }

  onShow() {
    this.submitted = false;
  }

  convertTimeDate(hours: any, minutes: any) {
    const today = new Date();
    return new Date(
      today.getFullYear(),
      today.getMonth(),
      today.getDate(),
      parseInt(hours, 10),
      parseInt(minutes, 10)
    );
  }

  closeDialog(event: any) {
    this.displayTrap = false;
    this.ngOnInit();
  }
  // nextRecords(e: any) {
  //   this.defaultSearchValues = false;
  //   this.Search.page = this.Search.page + 1;

  //   this.SearchFan(this.Search);
  // }
  SearchFan(Search?: any) {
    var datePipe = new DatePipe("en-US");


    this.submitted = true;
    this.Search.TrapId = this.trapId
    console.log(this.startDate);

    if (this.startDate) {
      // let start:Date = new Date() ;
      // start.setDate(this.startDate.getDate())
      this.Search.StartDate = `${datePipe.transform(this.startDate, "yyyy-MM-dd")}`
    }
    if (this.endDate) {
      // let end:Date = new Date() ;
      // end.setDate(this.endDate.getDate())
      this.Search.EndDate = `${datePipe.transform(this.endDate, "yyyy-MM-dd")}`
    }
    if (!this.Search.list && !this.Search.chart) return;
    if (this.Search.list) {
      this.trapService
        .GetAllTrapReadings(this.Search)
        .subscribe(
          (res: any) => {
            // this.totalRecords = +res.count;
            this.trapReadsPeriod = res.data;
            this.trapReadsPeriodTable = this.trapReadsPeriod.data;

            // for (let i = 0; i < this.trapReadsPeriod.data.length; i++) {
            //   // Latitude 
            //   if (this.trapReadsPeriod.data[i].id != -1) {
            //     this.trapReadsPeriodTable.push(
            //       this.trapReadsPeriod.data[i]
            //     );
            //     if (this.trapReadsPeriod.data[i].lat == 0) {
            //       let rNum = Math.floor(Math.random() * 9999);
            //       this.trapService.fakeLat = Number(
            //         this.trapReadsPeriod.data[i - 1]?.lat
            //           .toString()
            //           .substring(
            //             this.trapReadsPeriod.data[i - 1]?.lat.toString()
            //               .length - 3,
            //             0
            //           ) + rNum
            //       );
            //     }
            //     if (this.trapReadsPeriod.data[i].long == 0) {
            //       let rNum = Math.floor(Math.random() * 999);
            //       this.trapService.fakeLong = Number(
            //         this.trapReadsPeriod.data[i - 1]?.long
            //           .toString()
            //           .substring(
            //             this.trapReadsPeriod.data[i - 1]?.long.toString()
            //               .length - 3,
            //             0
            //           ) + rNum
            //       );
            //     }
            //   }
            // }
            // this.trapReadsPeriodTable.reverse();
          },
          (error: ErrorInterface) => {
            this.sharedService.handleError(error);
            this.messageService.add(this.sharedService.toastErrorHandler(error.message));
            // this.sharedService.handleError(error);
            // error.errors.forEach((err) => {
            //   this.messageService.add(
            //     this.sharedService.toastErrorHandler(err)
            //   );
            // });

          },
          () => { }
        );
    }

    if (this.Search.chart) {

      this.SearchChartData.data = [];
      this.SearchChartArrays = [];
      this.trapService
        .GetAllTrapReadingsPerDay(this.Search).subscribe(
          (res: any) => {
            this.SearchChartData.data = res.data;
            // this.SearchChartData.data.reverse();
            if (this.SearchChartData.data.length > 0) {
              this.SearchChartData.data.forEach((ele: any, i: number) => {
                let chartDaysNumber: any = {
                  TotalSmall: 0,
                  TotalLarge: 0,
                  TotalMosuqitoes: 0,
                  TotalFlys: 0,
                };

                let Small: any[] = [];
                let Large: any[] = [];
                let Mosuqitoes: any[] = [];
                let Other: any[] = [];
                let off: any[] = [];
                let on: boolean = false;
                let AllReding: any[] = res.data[i].trapReadingsData.sort((a: any, b: any) => {
                  let x: any = new Date(b.readingTime).getTime();
                  let y: any = new Date(a.readingTime).getTime();
                  return x > y ? 1 : -1
                });
                if (AllReding.length > 0) {
                  this.times.forEach((ele: any) => {
                    let index = AllReding.findIndex((item: any) => this.convertTime(item.readingTime) == this.convertTime(ele))
                    if (index != -1) {
                      // if (AllReding[index].counter !== 0) {
                      //   on = true;
                      // }
                      // if(AllReding.length - 1 == index){
                      //   on = false;
                      // }
                      if (AllReding[index].readingsmall) {
                        chartDaysNumber.TotalSmall += +AllReding[index].readingsmall | 0;
                      }
                      if (AllReding[index].readingLarg) {
                        chartDaysNumber.TotalLarge += +AllReding[index].readingLarg | 0;
                      }
                      if (AllReding[index].readingMosuqitoes) {
                        chartDaysNumber.TotalMosuqitoes += +AllReding[index].readingMosuqitoes | 0;
                      }
                      if (AllReding[index].readingFly) {
                        chartDaysNumber.TotalFlys += +AllReding[index].readingFly | 0;
                      }
                      if (AllReding[index].counter == null) {
                        AllReding[index].readingsmall = undefined;
                        AllReding[index].readingLarg = undefined;
                        AllReding[index].readingMosuqitoes = undefined;
                        AllReding[index].readingFly = undefined;
                        off.push(0);
                        Small.push(undefined);
                        Large.push(undefined);
                        Mosuqitoes.push(undefined);
                        Other.push(undefined);
                      } else {
                        off.push(0);
                        Small.push(AllReding[index].readingsmall | 0);
                        Large.push(AllReding[index].readingLarg | 0);
                        Mosuqitoes.push(AllReding[index].readingMosuqitoes | 0);
                        Other.push(AllReding[index].readingFly | 0);
                      }
                    } else if (AllReding[0].readingDate.slice(0, 10) == this.currentDate) {
                      const [hours, minutes] = ele.split(':');
                      if (this.convertTimeDate(this.currentHour, this.currentMinutes).getTime() < this.convertTimeDate(hours, minutes).getTime()) {
                        Small.push(undefined);
                        Large.push(undefined);
                        Mosuqitoes.push(undefined);
                        Other.push(undefined);
                        off.push(undefined);
                      } else {
                        Small.push(undefined);
                        Large.push(undefined);
                        Mosuqitoes.push(undefined);
                        Other.push(undefined);
                        off.push(0);
                      }
                    } else {
                      Small.push(0);
                      Large.push(0);
                      Mosuqitoes.push(0);
                      Other.push(0);
                      off.push(0);
                    }
                  })
                }
                this.SearchChartArrays.push({
                  labels: this.times,
                  datasets: [
                    {
                      type: 'line',
                      label: 'Small Mosuqitoes (Total:' + chartDaysNumber.TotalSmall + ') ',
                      borderColor: '#307bb2',
                      borderWidth: 2,
                      fill: false,
                      data: Small,
                    },
                    {
                      type: 'line',
                      label: 'Large Mosuqitoes (Total:' + chartDaysNumber.TotalLarge + ') ',
                      borderColor: 'rgb(255, 69, 96)',
                      borderWidth: 2,
                      fill: false,
                      data: Large,
                    },
                    {
                      type: 'line',
                      label:
                        'Mosuqitoes (Total:' +
                        chartDaysNumber.TotalMosuqitoes +
                        ') ',
                      borderColor: '#54aa54',
                      borderWidth: 2,
                      fill: false,
                      data: Mosuqitoes,
                    },
                    {
                      type: 'line',
                      label: 'Other (Total:' + chartDaysNumber.TotalFlys + ') ',
                      borderColor: '#ffc107',
                      borderWidth: 2,
                      fill: false,
                      data: Other,
                    },
                    {
                      type: 'line',
                      label: 'OFF',
                      borderColor: '#ccc',
                      borderWidth: 2,
                      fill: false,
                      data: off,
                    },
                  ],
                });
              });

            }
          },
          (error: ErrorInterface) => {
            this.sharedService.handleError(error);
            this.messageService.add(this.sharedService.toastErrorHandler(error.message));
          },
          () => { }
        );
    }
    if (this.Search.list || this.Search.chart) this.displayDialog = false;
  }

  SearchLastDay(Search?: any) {
    // this.query.StartDate = this.dateNow.toISOString().slice(0, 10);
    // this.query.EndData = this.dateNow.toISOString().slice(0, 10);
    this.query.TrapId = this.trapId
    this.trapService
      .GetAllTrapReadings(this.query)
      .subscribe(
        (res: any) => {
          this.trapReads = res.data;
          // this.trapService.fakeLat = this.trapReads.data[1].lat;
          // this.trapService.fakeLong = this.trapReads.data[1].long;

          // for (let i = 0; i < this.trapReads.data.length; i++) {
          //   if (this.trapReads.data[i].id != -1) {
          //     this.trapDayReads.push(this.trapReads.data[i]);
          //   }
          // }
          // this.trapDayReads.reverse();
        },
        (error: ErrorInterface) => {
          this.sharedService.handleError(error);
          this.messageService.add(this.sharedService.toastErrorHandler(error.message));
        },
        () => {
        }
      );
  }

  getLastDayExcel() {
    let query: any = {};
    query.TrapId = this.trapId
    this.trapService
      .GetAllTrapReadings(query)
      .subscribe(
        (res: any) => {
          this.trapDayReads = res.data.data;
          this.exportExcel(this.trapDayReads)
        },
        (error: ErrorInterface) => {
          this.sharedService.handleError(error);
          this.messageService.add(this.sharedService.toastErrorHandler(error.message));
        },
        () => {
        }
      );
  }

  getALLDataExcel() {
    this.loadingExcel = true;
    let query: any = {};
    query.TrapId = this.trapId
    query.StartDate = this.Search.StartDate
    query.EndDate = this.Search.EndDate

    this.trapService
      .GetAllTrapReadings(query)
      .subscribe(
        (res: any) => {
          this.exportExcel(res.data.data)
          this.loadingExcel = false;
        },
        (error: ErrorInterface) => {
          this.sharedService.handleError(error);
          this.loadingExcel = false;
          this.messageService.add(this.sharedService.toastErrorHandler(error.message));
        },
        () => {
        }
      );
  }
  // getLastRead() {
  //   this.trapService
  //     .GetLastReadingToSpecifiedTrap(this.trapId)
  //     .subscribe(
  //       (res: any) => {
  //         this.LastReadForTrap = res.data;
  //         this.MapData.next(this.LastReadForTrap);
  //         this.MapData.complete();
  //       },

  //     );
  // }

  GetLastReadingToSpecifiedAllEmptyValueILatAndLongTrap() {
    this.trapService
      .GetLastReadingToSpecifiedAllEmptyValueILatAndLongTrap(this.trapId)
      .subscribe(
        (res: any) => {
          this.LastReadForTrap = res.data;
          this.MapData.next(this.LastReadForTrap);
          this.MapData.complete();
        },

      );
  }

  getTodayRead() {

    let filter: any = {};
    // filter.StartDate = this.dateNow.toISOString().slice(0, 10);
    // filter.EndData = this.dateNow.toISOString().slice(0, 10);
    filter.TrapId = this.trapId
    this.trapService
      .GetAllTrapReadings(filter)
      .subscribe(
        (res: any) => {
          let chartDay: any = {
            TotalSmall: 0,
            TotalLarge: 0,
            TotalMosuqitoes: 0,
            TotalFlys: 0,
          };

          let Small: any[] = [];
          let Large: any[] = [];
          let Mosuqitoes: any[] = [];
          let Other: any[] = [];
          let off: any[] = [];
          let AllReding: any[] = res.data.data;
          let on: boolean = false;
          if (AllReding.length > 0) {
            this.times.forEach((ele: any) => {
              let index = AllReding.findIndex((item: any) => this.convertTime(item.readingTime) == this.convertTime(ele))
              if (index != -1) {
                // if (AllReding[index].counter !== 0) {
                //   on = true;
                // }
                // if(AllReding.length - 1 == index){
                //   on = false;
                // }
                if (AllReding[index].readingsmall) {
                  chartDay.TotalSmall += +AllReding[index].readingsmall | 0;
                }
                if (AllReding[index].readingLarg) {
                  chartDay.TotalLarge += +AllReding[index].readingLarg | 0;
                }
                if (AllReding[index].readingMosuqitoes) {
                  chartDay.TotalMosuqitoes += +AllReding[index].readingMosuqitoes | 0;
                }
                if (AllReding[index].readingFly) {
                  chartDay.TotalFlys += +AllReding[index].readingFly | 0;
                }
                if (AllReding[index].counter == null) {
                  AllReding[index].readingsmall = undefined;
                  AllReding[index].readingLarg = undefined;
                  AllReding[index].readingMosuqitoes = undefined;
                  AllReding[index].readingFly = undefined;
                  off.push(0);
                  Small.push(undefined);
                  Large.push(undefined);
                  Mosuqitoes.push(undefined);
                  Other.push(undefined);
                } else {
                  off.push(0);
                  Small.push(AllReding[index].readingsmall | 0);
                  Large.push(AllReding[index].readingLarg | 0);
                  Mosuqitoes.push(AllReding[index].readingMosuqitoes | 0);
                  Other.push(AllReding[index].readingFly | 0);
                }
              } else if (AllReding[0].readingDate.slice(0, 10) == this.currentDate) {
                const [hours, minutes] = ele.split(':');
                if (this.convertTimeDate(this.currentHour, this.currentMinutes).getTime() < this.convertTimeDate(hours, minutes).getTime()) {
                  Small.push(undefined);
                  Large.push(undefined);
                  Mosuqitoes.push(undefined);
                  Other.push(undefined);
                  off.push(undefined);
                } else {
                  Small.push(undefined);
                  Large.push(undefined);
                  Mosuqitoes.push(undefined);
                  Other.push(undefined);
                  off.push(0);
                }
              } else {
                Small.push(0);
                Large.push(0);
                Mosuqitoes.push(0);
                Other.push(0);
                off.push(0);
              }
            })
          }

          this.data = {
            labels: this.times,
            datasets: [
              {
                type: 'line',
                label: 'Small Mosuqitoes (Total:' + chartDay.TotalSmall + ') ',
                borderColor: '#307bb2',
                borderWidth: 2,
                fill: false,
                data: Small,
              },
              {
                type: 'line',
                label: 'Large Mosuqitoes (Total:' + chartDay.TotalLarge + ') ',
                borderColor: 'rgb(255, 69, 96)',
                borderWidth: 2,
                fill: false,
                data: Large,
              },
              {
                type: 'line',
                label: 'Mosuqitoes (Total:' + chartDay.TotalMosuqitoes + ') ',
                borderColor: '#54aa54',
                borderWidth: 2,
                fill: false,
                data: Mosuqitoes,
              },
              {
                type: 'line',
                label: 'Other (Total:' + chartDay.TotalFlys + ') ',
                borderColor: '#ffc107',
                borderWidth: 2,
                fill: false,
                data: Other,
              },
              {
                type: 'line',
                label: 'OFF',
                borderColor: '#ccc',
                borderWidth: 2,
                fill: false,
                data: off,
              },
            ],
          };

          ///////// mix Chart ///////////////////

          // this.fullData = {
          //   labels: this.times,
          //   datasets: [
          //     {
          //       type: 'bar',
          //       label: 'Co2 blue',
          //       // backgroundColor: '#dde8fa',
          //       backgroundColor: '#00f',
          //       data: x100,
          //     },
          //     {
          //       type: 'bar',
          //       label: 'Fan Green',
          //       backgroundColor: '#0f0',
          //       data: x100,
          //     },
          //     {
          //       type: 'bar',
          //       label: 'Counter Red',
          //       // backgroundColor: '#fee3c8',
          //       backgroundColor: '#f00',
          //       data: x100,
          //     },
          //   ],
          // };

          this.chartToday.next(chartDay);
        },
        (error: ErrorInterface) => {
          this.sharedService.handleError(error);
          this.messageService.add(this.sharedService.toastErrorHandler(error.message));
          // this.sharedService.handleError(error);
          // error.errors.forEach((err) => {
          //   this.messageService.add(this.sharedService.toastErrorHandler(err));
          // });
        },
        () => { }
      );
  }
  viewCartIndex: number = 0;
  viewCartDate: any = '';
  viewCart(index: number, date: any) {
    this.viewCartDate = date;
    this.viewCartIndex = index;
    this.viewChart = true;
  }

  ngOnDestroy() {
    this.sharedService.trapTitle = 'BIOTRAPS';
    this.pauseAudio();
  }

  // Start Export
  async exportExcel(array: ReadData[]) {

    if (array.length > 0) {
      const excel = new GenerateExcel();
      const workbook = new Workbook();
      const worksheet = workbook.addWorksheet('Sharing Data');
      // Add Row and formatting
      worksheet.addRow([]);
      const titleRow1 = worksheet.addRow([
        'Electronic Insect Monitoring Station',
      ]);
      excel.headStyle1(titleRow1);
      excel.mergeCell('A2:C3', worksheet);
      //Add Image
      await excel
        .getBase64ImageFromUrl('assets/img/logo.png')
        .then((dataUrl: any) => {
          let logo = workbook.addImage({ base64: dataUrl, extension: 'png' });
          worksheet.addImage(logo, 'L1:L5');
        });
      worksheet.addRow([]);
      // Add Row and formatting
      const titleRow = worksheet.addRow(['Reading Report']);
      excel.headStyle2(titleRow);
      excel.mergeCell('A5:R6', worksheet);
      //Add Content
      worksheet.addRow([]);
      worksheet.addRow([]);
      // Add Header Row
      const headerRow = worksheet.addRow([
        'Trap Name',
        'Reading Date',
        'Time',
        'Latitude',
        'Longitude',
        'Counter',
        'Fan',
        'Co2',
        'Co2 Valve',
        'Small Mosuqitoes',
        'Large Mosuqitoes',
        'Mosuqitoes',
        'Other',
        'Temperature',
        'WindSpeed',
        'Humidity',
      ]);

      // Cell Style : Fill and Border
      excel.tableHeadStyle1(headerRow);
      // Add Data and Conditional Formatting
      array.forEach((d) => {
        let row = worksheet.addRow([
          this.trapDetails.name,
          d.readingDate,
          d.readingTime,
          d.lat,
          d.long,
          d.counter,
          d.fan,
          d.co2,
          d.co2Val,
          d.readingsmall,
          d.readingLarg,
          d.readingMosuqitoes,
          d.readingFly,
          d.readingTempIn,
          d.readingWindSpeed,
          d.readingHumidty,
        ]);
        row.alignment = { vertical: 'middle', horizontal: 'center' };
      });

      worksheet.columns.forEach((column, index) => {
        column.width = 15;
      });
      workbook.xlsx.writeBuffer().then((data: any) => {
        const blob = new Blob([data], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        fs.saveAs(blob, 'Reading Report_' + new Date().getDate() + '.xlsx');
      });
    } else console.log('NO Rows Found');
  }

  async exportpdf(type = 0, id: string = '', titleid: string = '') {
    this.Exportloading = true;
    let PDF = new jsPDF('p', 'mm', 'a4');
    await this.sharedService.htmlToImage('logo', PDF, 2, 2, 25);
    PDF.text('Report', 100, 16);
    PDF.text('Trap Details', 2, 35);

    PDF.text('Trap Name : Trap Name', 10, 45);
    PDF.text('Iema : ' + this.trapDetails?.iema, 90, 45);
    PDF.text('Counter : ' + this.trapDetails.isCounterOn, 160, 45);

    PDF.text('Serial Namber : ' + this.trapDetails.serialNumber, 10, 55);
    PDF.text('Reading Date : ' + this.trapDetails.readingDate, 105, 55);

    if (type == 0) {
      await this.sharedService.htmlToImage('trapMap2title', PDF, 0, 60);
      await this.sharedService.htmlToImage('trapMap2', PDF, 0, 67);
      await this.sharedService.htmlToImage('trapMap3title', PDF, 0, 130);
      await this.sharedService.htmlToImage('trapMap3', PDF, 0, 137);
    } else {
      await this.sharedService.htmlToImage(titleid, PDF, 0, 60);
      await this.sharedService.htmlToImage(id, PDF, 0, 67);
    }

    PDF.save('Report.pdf');
    this.Exportloading = false;
  }

  async exportWord(type: number = 0, id: string = '', title: string = '') {
    try {
      this.Exportloading = true;
      let data =
        ',trap Name,' +
        this.trapDetails.iema +
        ',' +
        this.trapDetails.isCounterOn +
        ',' +
        this.trapDetails.serialNumber +
        ',' +
        this.trapDetails.readingDate;
      let formData = new FormData();
      if (type == 0) {
        await this.sharedService.htmlToCanvasWithAppendFormData(
          'trapMap1',
          formData,
          'Last Location' + data
        );
        await this.sharedService.htmlToCanvasWithAppendFormData(
          'trapMap2',
          formData,
          'Today Read' + data
        );
        await this.sharedService.htmlToCanvasWithAppendFormData(
          'trapMap3',
          formData,
          'Last Week Read' + data
        );
      } else
        await this.sharedService.htmlToCanvasWithAppendFormData(
          id,
          formData,
          title + data
        );

      this.reportService
        .getTrapDetailsReport(formData)
        .subscribe((res: ArrayBuffer) => {
          const byteArray = new Uint8Array(res);
          const url = window.URL.createObjectURL(new Blob([byteArray]));
          const link = document.createElement('a');
          link.href = url;
          link.setAttribute('download', 'Report.docx');
          document.body.appendChild(link);
          link.click();
        });
      this.Exportloading = false;
    } catch (err) {
      this.Exportloading = false;
      console.log('Error When Get Promise');
    }
  }

  async exportAllDailyChartsPdf() {
    if (this.SearchChartData.data.length > 0) {
      this.Exportloading = true;
      let PDF = new jsPDF('p', 'mm', 'a4');
      await this.sharedService.htmlToImage('logo', PDF, 2, 2, 25);
      PDF.text('Report', 100, 16);
      PDF.text('Trap Details', 2, 35);

      PDF.text('Trap Name : Trap Name', 10, 45);
      PDF.text('Iema : ' + this.trapDetails.iema, 90, 45);
      PDF.text('Counter : ' + this.trapDetails.isCounterOn, 160, 45);

      PDF.text('Serial Namber : ' + this.trapDetails.serialNumber, 10, 55);
      PDF.text('Reading Date : ' + this.trapDetails.readingDate, 105, 55);

      let top = 0;
      for (
        let index = 0;
        index < this.SearchChartData.data.length;
        index++
      ) {
        if (index > 2) {
          if (index % 3 == 0) {
            await this.sharedService.htmlToImage(
              'trapDetailstitle' + index,
              PDF,
              0,
              (top += 5)
            );
            await this.sharedService.htmlToImage(
              'trapDetails' + index,
              PDF,
              0,
              top + 7
            );
          } else {
            await this.sharedService.htmlToImage(
              'trapDetailstitle' + index,
              PDF,
              0,
              (top += 60)
            );
            await this.sharedService.htmlToImage(
              'trapDetails' + index,
              PDF,
              0,
              (top += 7)
            );
          }
        } else {
          await this.sharedService.htmlToImage(
            'trapDetailstitle' + index,
            PDF,
            0,
            (top += 60)
          );
          await this.sharedService.htmlToImage(
            'trapDetails' + index,
            PDF,
            0,
            (top += 7)
          );
        }

        if ((index + 1) % 3 == 0) {
          top = 0;
          PDF.addPage('', 'p');
        }
      }

      PDF.save('Report.pdf');
      this.Exportloading = false;
    } else console.log('NO Rows Found');
  }

  exportExcelSearch() {
    let searchQuery: any = {};
    searchQuery['StartDate'] = this.Search.StartDate;
    searchQuery['EndDate'] = this.Search.EndDate;
    searchQuery['TrapId'] = this.Search.TrapId;
    console.log(searchQuery);

    this.trapService
      .GetAllTrapReadings(searchQuery)
      .subscribe(
        async (res: any) => {
          res.data.data
          if (res.data.data.length > 0) {
            const excel = new GenerateExcel();
            const workbook = new Workbook();
            const worksheet = workbook.addWorksheet('Sharing Data');
            // Add Row and formatting
            worksheet.addRow([]);
            const titleRow1 = worksheet.addRow([
              'Electronic Insect Monitoring Station',
            ]);
            excel.headStyle1(titleRow1);
            excel.mergeCell('A2:C3', worksheet);
            //Add Image
            await excel
              .getBase64ImageFromUrl('assets/img/logo.png')
              .then((dataUrl: any) => {
                let logo = workbook.addImage({ base64: dataUrl, extension: 'png' });
                worksheet.addImage(logo, 'L1:L5');
              });
            worksheet.addRow([]);
            // Add Row and formatting
            const titleRow = worksheet.addRow(['Reading Report']);
            excel.headStyle2(titleRow);
            excel.mergeCell('A5:R6', worksheet);
            //Add Content
            worksheet.addRow([]);
            worksheet.addRow([]);
            // Add Header Row
            const headerRow = worksheet.addRow([
              'Trap Name',
              'Reading Date',
              'Time',
              'Latitude',
              'Longitude',
              'Counter',
              'Fan',
              'Co2',
              'Co2 Valve',
              'Small Mosuqitoes',
              'Large Mosuqitoes',
              'Mosuqitoes',
              'Other',
              'Temperature',
              'WindSpeed',
              'Humidity',
            ]);

            // Cell Style : Fill and Border
            excel.tableHeadStyle1(headerRow);
            // Add Data and Conditional Formatting
            res.data.data.forEach((d: any) => {
              let row = worksheet.addRow([
                this.trapDetails.name,
                d.readingDate,
                d.readingTime,
                d.lat,
                d.long,
                d.counter,
                d.fan,
                d.co2,
                d.co2Val,
                d.readingsmall,
                d.readingLarg,
                d.readingMosuqitoes,
                d.readingFly,
                d.readingTempIn,
                d.readingWindSpeed,
                d.readingHumidty,
              ]);
              row.alignment = { vertical: 'middle', horizontal: 'center' };
            });

            worksheet.columns.forEach((column, index) => {
              column.width = 15;
            });
            workbook.xlsx.writeBuffer().then((data: any) => {
              const blob = new Blob([data], {
                type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
              });
              fs.saveAs(blob, 'Reading From ' + searchQuery['StartDate'] + 'To ' + searchQuery['EndDate'] + '.xlsx');
            });
          } else console.log('NO Rows Found');
        },
        (error: ErrorInterface) => {
          this.sharedService.handleError(error);
          this.messageService.add(this.sharedService.toastErrorHandler(error.message));
        },
        () => { }
      );
  }
}
