import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TrapService } from '@modules/services/trap.service';
import { SharedService } from '@modules/shared.service';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-states',
  templateUrl: './states.component.html',
  styleUrls: ['./states.component.css']
})
export class StatesComponent implements OnInit {
  allCategories: any[] = [];
  loading: boolean = true;
  myRole: string = '';
  formCategory!: FormGroup;
  id: number = 0;
  displayCategory: boolean = false;
  categoryDetails: any;
  
  constructor(
    public sharedService: SharedService,
    private trapService: TrapService,
    private messageService: MessageService,
    private _formBuilder: FormBuilder
  ) {
    this.formCategory = this._formBuilder.group({
      name: ['', Validators.required]
    })
  }

  ngOnInit(): void {
    this.myRole = localStorage.getItem('trap_role')!;
    this.GetAllCategories();
  }

  openCategory() {
    this.id = 0;
    this.formCategory.reset();
    this.displayCategory = true;
  }

  openUpdateCategory(categoory:any) {
    this.formCategory.reset();
    this.formCategory.patchValue({
      name: categoory.name
    })
    this.categoryDetails = categoory
    this.id = categoory.id;
    this.displayCategory = true;
  }
  GetAllCategories() {
    this.loading = true;
    this.trapService.GetAllCategories().subscribe({
      next: (res: any) => {
        this.allCategories = res.data
        this.loading = false;
      },
      error: (error: any) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
        this.loading = false;
      }
    })
  }

  submitCategory() {
    this.id ? this.UpdateCategory() : this.CreateCategory();
  }

  CreateCategory() {
    let value = {};
    value = this.formCategory.value;
    this.trapService.CreateCategory(value).subscribe({
      next: (res: any) => {
        this.GetAllCategories();
        this.displayCategory = false;
        this.sharedService.toastSuccessRequest('Catgory added successfully')
      }, error: (err: any) => {
        this.sharedService.toastErrorHandler('failed')
      }
    })
  }

  UpdateCategory() {
    let value: any = {};
    value = this.formCategory.value;
    value['id'] = this.id;

    this.trapService.UpdateCategory(value).subscribe({
      next: (res: any) => {
        this.GetAllCategories();
        this.displayCategory = false;
        this.sharedService.toastSuccessRequest('Catgory Updated successfully')
      }, error: (err: any) => {
        this.sharedService.toastErrorHandler('failed')
      }
    })
  }

  DeleteCategory(id: number) {
    this.trapService.DeleteCategory(id).subscribe({
      next: (res: any) => {
        this.GetAllCategories();
        this.sharedService.toastSuccessRequest('Catgory Deleted successfully')
      }, error: (err: any) => {
        this.sharedService.toastErrorHandler('failed')
      }
    })
  }


}
