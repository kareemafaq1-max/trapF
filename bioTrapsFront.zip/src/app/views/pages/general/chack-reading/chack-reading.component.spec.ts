import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChackReadingComponent } from './chack-reading.component';

describe('ChackReadingComponent', () => {
  let component: ChackReadingComponent;
  let fixture: ComponentFixture<ChackReadingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChackReadingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChackReadingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
