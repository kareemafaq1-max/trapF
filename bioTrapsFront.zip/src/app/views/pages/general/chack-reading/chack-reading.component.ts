import { DatePipe } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { ErrorInterface } from '@modules/error.interface';
import { TrapService } from '@modules/services/trap.service';
import { SharedService } from '@modules/shared.service';
import { MessageService } from 'primeng/api';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-chack-reading',
  templateUrl: './chack-reading.component.html',
  styleUrls: ['./chack-reading.component.css']
})
export class ChackReadingComponent implements OnInit, OnDestroy {
  private ngUnsubscribe = new Subject<void>();
  displayDelete: boolean = false;
  submitted: boolean = false;
  allLoadDate: any[] = [];
  filterForm!: FormGroup;
  currentDate: Date = new Date();

  constructor(
    public sharedService: SharedService,
    private fb: FormBuilder,
    private messageService: MessageService,
    private _trapService: TrapService,
    private _activatedRoute: ActivatedRoute
  ) {
    this.filterForm = this.fb.group({
      fromDate: [null, [Validators.required]],
      toDate: [null, [Validators.required]],
      Serial: [null]
    })
    this._activatedRoute.paramMap.subscribe((param: ParamMap) => {
      var datePipe = new DatePipe("en-US");
      this.filterForm.get('Serial')?.patchValue(param.get('serial'));
      this.filterForm.get('fromDate')?.patchValue(this.currentDate);
      this.filterForm.get('toDate')?.patchValue(this.currentDate);
      this.GetAllLoadDate();
    })
  }

  ngOnInit() { }

  GetAllLoadDate() {
    var datePipe = new DatePipe("en-US");
    let value: any = this.filterForm.value;
    value['fromDate'] = datePipe.transform(value.fromDate, "yyyy-MM-dd");
    value['toDate'] = datePipe.transform(value.toDate, "yyyy-MM-dd");
    this._trapService.LoadData2Logs(value).pipe(takeUntil(this.ngUnsubscribe)).subscribe(
      (res: any) => {
        this.allLoadDate = res.data;
      },
      (error: ErrorInterface) => {
        this.sharedService.handleError(error);
        this.messageService.add(this.sharedService.toastErrorHandler(error.message));
      }
    );
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
}
