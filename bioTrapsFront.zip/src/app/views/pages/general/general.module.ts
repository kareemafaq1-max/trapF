import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GeneralComponent } from './general.component';
import { RouterModule, Routes } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { SharedModule } from '@modules/shared.module';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { HomeComponent } from './home/home.component';
import { HttpLoaderFactory } from '@modules/shared.service';
import { LayoutModule } from '@modules/layout.module';
import { YourTrapsComponent } from './yourTraps/yourTraps.component';
import { TrapDetailsComponent } from './trapDetails/trapDetails.component';
import { GoogleChartsModule } from 'angular-google-charts';
import { AllTrapsComponent } from './allTraps/allTraps.component';
import { UsersComponent } from './users/users.component';
import { ChartModule } from 'primeng/chart';
import { ManagementUserComponent } from './users/managementUser/managementUser.component';
import { TestComponent } from './test/test.component';
import { ManagmentTrapComponent } from './allTraps/managmentTrap/managmentTrap.component';
import { EmergencyComponent } from './emergency/emergency.component';
import { DropdownModule } from 'primeng/dropdown';
import { PaginatorModule } from 'primeng/paginator';
import { InputSwitchModule } from 'primeng/inputswitch';
import { ChartsModule } from '@modules/components/charts.module';
import { KnobModule } from 'primeng/knob';
import { AuthGuard } from '@modules/auth.guard';
import { LoadingModule } from '@modules/loading/loading.module';
import { StatesComponent } from './states/states.component';
import { MessageModule } from 'primeng/message';
import { SkeletonModule } from 'primeng/skeleton';
import { AccordionModule } from 'primeng/accordion';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { ViewChartByTrapComponent } from './view-chart-by-trap/view-chart-by-trap.component';
import { ChackReadingComponent } from './chack-reading/chack-reading.component';
const routes: Routes = [
  {
    path: '',
    component: GeneralComponent,
    children: [
      { path: '', component: HomeComponent , canActivate: [AuthGuard] },
      { path: 'catgories', component: StatesComponent , canActivate: [AuthGuard] },
      { path: 'catgories/:id', component: YourTrapsComponent , canActivate: [AuthGuard] },
      { path: 'yourTraps', component: YourTrapsComponent , canActivate: [AuthGuard] },
      { path: 'yourTraps/:id', component: TrapDetailsComponent , canActivate: [AuthGuard] },
      { path: 'users', component: UsersComponent , canActivate: [AuthGuard] },
      { path: 'users/addUser', component: ManagementUserComponent , canActivate: [AuthGuard] },
      { path: 'users/editUser/:id', component: ManagementUserComponent , canActivate: [AuthGuard] },
      { path: 'users/editPasswordUser/:id', component: ManagementUserComponent , canActivate: [AuthGuard] },
      { path: 'allTraps', component: AllTrapsComponent , canActivate: [AuthGuard] },
      { path: 'emergency/:id', component: EmergencyComponent , canActivate: [AuthGuard] },
      { path: 'allTraps/addTrap', component: ManagmentTrapComponent , canActivate: [AuthGuard] },
      { path: 'allTraps/editTrap/:id', component: ManagmentTrapComponent , canActivate: [AuthGuard] },
      { path: 'test', component: TestComponent , canActivate: [AuthGuard] },
      { path: 'view-trap/:id', component: ViewChartByTrapComponent , canActivate: [AuthGuard] },
      { path: 'check-reading/:serial', component: ChackReadingComponent, canActivate: [AuthGuard] },
    ],
  },
];

@NgModule({
  declarations: [
    //component
    GeneralComponent,
    HomeComponent,
    YourTrapsComponent,
    TrapDetailsComponent,
    UsersComponent,
    AllTrapsComponent,
    ManagementUserComponent,
    ManagmentTrapComponent,
    TestComponent,
    EmergencyComponent,
    StatesComponent,
    ViewChartByTrapComponent,
    ChackReadingComponent
  ],
  imports: [
    ChartModule,
    CommonModule,
    SharedModule,
    LoadingModule,
    OverlayPanelModule,
    HttpClientModule,
    LayoutModule,
    GoogleChartsModule,
    DropdownModule,
    ButtonModule,
    PaginatorModule,
    InputSwitchModule,
    KnobModule,
    DialogModule,
    SkeletonModule,
    ChartsModule,
    MessageModule,
    RouterModule.forChild(routes),
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient],
      },
    }),
    AccordionModule
  ],
  exports: [
    ChartModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class GeneralModule { }
