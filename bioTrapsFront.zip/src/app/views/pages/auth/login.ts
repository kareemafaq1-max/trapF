export interface Login {
  data: {
    role: string;
    token: string;
    expiresOn: Date;
    userId:string;
  },
}
