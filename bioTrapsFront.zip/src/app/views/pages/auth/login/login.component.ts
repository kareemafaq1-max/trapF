import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ErrorInterface } from '@modules/error.interface';
import { SharedService } from '@modules/shared.service';
import { MessageService } from 'primeng/api';
import { LoginService } from '@modules/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submit: boolean = false;
  loading: boolean = false;
  constructor(
    private loginService: LoginService,
    private fb: FormBuilder,
    public sharedService: SharedService,
    private messageService: MessageService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    // ##Admin##00@test.com
    // Admin#2020
    this.loginForm = this.fb.group({
      userNameOrEmail: ['', [Validators.required, Validators.email]],
      Password: ['', [Validators.required]],
    });
  }
  date = new Date();

  get login() {
    return this.loginForm.controls;
  }

  ngOnInit() { }

  Save() {
    this.messageService.clear('backEnderror');
    this.submit = true;
    if (this.loginForm.invalid) return;
    this.loading = true;
    if (this.submit && this.loginForm.valid) {
      this.loginService.login(this.loginForm.value).subscribe(
        (res:any) => {
          localStorage.setItem('trap_token', `Bearer ${res.data.token}`);
          localStorage.setItem('trap_role', res.data.role);
          localStorage.setItem('userId', res.data.userId);
          localStorage.setItem('userName', res.data.userName);
          this.loading = false;
        },
        (error: ErrorInterface) => {
          this.sharedService.handleError(error);
          this.messageService.add(this.sharedService.toastErrorHandler(error.message));
          this.loading = false;
          // error.errors.forEach((err) => {
          // });
        },
        () => {
          this.clearSave();
        }
      );
    }
  }

  clearSave() {
    this.submit = false;
    this.sharedService.loading = false;
    let pageBeforeLogin = this.route.snapshot.queryParams['returnUrl'];
    if (pageBeforeLogin) this.router.navigateByUrl(pageBeforeLogin);
    else {

      this.router.navigateByUrl('');
      // if (this.sharedService.getRole() == "SuperAdmin") {
      //   this.router.navigateByUrl('');
      // } else if (this.sharedService.getRole() == "User" || this.sharedService.getRole() == "UserChild") {
      //   this.router.navigateByUrl('/yourTraps');
      // }
    }




  }
}
