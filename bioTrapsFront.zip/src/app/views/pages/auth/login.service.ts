import { HttpClient } from '@angular/common/http';
import { environment as env } from '@env/environment';
import { Injectable } from '@angular/core';
import { Login } from './login';

@Injectable({
  providedIn: 'root',
})
export class LoginService {
  constructor(private http: HttpClient) {}

  base_URL: string = env.apiPath + 'Auth/';

  login(data: any) {
    return this.http.post<Login>(this.base_URL + 'LoginUser', data);
  }
}
